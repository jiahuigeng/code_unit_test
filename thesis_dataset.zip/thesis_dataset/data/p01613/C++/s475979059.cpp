#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

struct P{
	int x, y;
	P(){}
	P(int x_, int y_){ x = x_; y = y_; }
};

int D(P a, P b){
	return abs(a.x - b.x) + abs(a.y - b.y);
}

int main(){
	const int INF = 1e+8;
	int n, a, b, c, d, ans = INF;
	cin >> n >> a >> b >> c >> d;
	a--; b--; c--; d--;
	for(int w = 1; w <= n; w++){
		int k = 0;
		P pa, pb, pc, pd;
		for(int y = 0; y < n; y++){
			for(int x = 0; x < w; x++){
				if( k == a ) pa = P(x, y);
				if( k == b ) pb = P(x, y);
				if( k == c ) pc = P(x, y);
				if( k == d ) pd = P(x, y);
				k++;
			}
		}
		int d = D(pa, pb) + D(pc, pd);
		ans = min(ans, d);
	}
	cout << ans << endl;
}