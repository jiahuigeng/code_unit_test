#include<iostream>
using namespace std;

#define INF 100000000
#define min(a,b) (a>b?b:a)

int dist(int a, int b, int x) {
  if(a>b) return dist(b,a,x);
  int r1 = (b/x)-(a/x);
  int r2 = (b-a)%x;
  return r1+r2;
}

int main() {
  int n, a, b, c, d, ans=INF;
  cin >> n >> a >> b >> c >> d;
  for(int i=1; i<n; ++i) {
    ans = min(ans, dist(a, b, i) + dist(c, d, i));
  }
  cout << ans << endl;
  return 0;
}