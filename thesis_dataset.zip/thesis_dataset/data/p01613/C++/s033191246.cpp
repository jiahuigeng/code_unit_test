#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
	int n; cin >> n;
	int res = 1<<29;
	int a, b, c, d; cin >> a >> b >> c >> d;
	for (int i = 1; i <= n; i++) {
		int ax = a%i, ay = a/i;
		int bx = b%i, by = b/i;
		int cx = c%i, cy = c/i;
		int dx = d%i, dy = d/i;
		int tmp = abs(ax-bx)+abs(ay-by)+abs(cx-dx)+abs(cy-dy);
		res = min(res, tmp);
	}
	cout << res << endl;

	return 0;
}