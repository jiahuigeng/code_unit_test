#include<iostream>
#include<cstdio>
#include<cmath>
#include<vector>
#include<queue>
#include<map>
#include<algorithm>
#include<complex>
#include<string>
#include<cstring>
using namespace std;
#define rep2(x,from,to) for(int x=(from);(x)<(to);(x)++)
#define rep(x,to) rep2(x,0,to)
#define INF 10000000
#define MAX_OTURI 50005
#define all(x) x.begin(),x.end()
typedef pair<int,int> P;
typedef pair<int,P> PP;
int n;
int a,b,c,d;
int aa,bb,cc,dd;
int aaa,bbb,ccc,ddd;
int ans;
int main()
{
	ans=INF;
	cin>>n>>a>>b>>c>>d;
	a--;b--;c--;d--;
	rep2(i,1,n+1)
	{
		aa=a/i;
		aaa=a%i;
		bb=b/i;
		bbb=b%i;
		cc=c/i;
		ccc=c%i;
		dd=d/i;
		ddd=d%i;
		ans=min(ans,abs(aa-bb)+abs(aaa-bbb)+abs(cc-dd)+abs(ccc-ddd));
	}
	cout<<ans<<endl;
	return 0;
}