n = int(input())
a, b = map(int, input().split())
c, d = map(int, input().split())


def get_dist(w, a, b):
    return sum(map(lambda x, y: abs(x - y), divmod(a, w), divmod(b, w)))


print(min(get_dist(w, a, b) + get_dist(w, c, d) for w in range(1, n + 1)))