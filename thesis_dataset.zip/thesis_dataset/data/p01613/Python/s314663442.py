n = int(input())
a, b = map(int, input().split())
c, d = map(int, input().split())


def get_dist(w, a, b):
    return sum(map(lambda x, y: abs(x - y), divmod(a, w), divmod(b, w)))


print(min(get_dist(w, a - 1, b - 1) + get_dist(w, c - 1, d - 1) for w in range(1, n + 1)))