n = int(input())
a, b = map(int, input().split())
c, d = map(int, input().split())
ans = 10 ** 3
for w in range(1, n + 1):
  ax, ay = a % w, a // w
  bx, by = b % w, b // w
  cx, cy = c % w, c // w
  dx, dy = d % w, d // w
  ans = min(ans, abs(ax - bx) + abs(ay - by) + abs(cx - dx) + abs(cy - dy))
print(ans)
