#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_DEPRECATE

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>
#include <cfloat>
#include <ctime>
#include <cassert>
#include <map>
#include <utility>
#include <set>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <sstream>
#include <complex>
#include <stack>
#include <queue>
#include <numeric>
#include <list>
#include <iomanip>
#include <fstream>
#include <iterator>
#include <bitset>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> Pii;
typedef pair<ll, ll> Pll;

#define FOR(i,n) for(int i = 0; i < (n); i++)
#define sz(c) ((int)(c).size())
#define ten(x) ((int)1e##x)
#define tenll(x) ((ll)1e##x)

const int N = 300000;
int a[N], b[N], c[N];
ll asum[N + 1];

int main(){
	int n;
	cin >> n;
	FOR(i, n) cin >> a[i];
	int m; cin >> m;
	FOR(i, m) cin >> b[i];
	FOR(i, m) cin >> c[i];

	sort(a, a + n);
	FOR(i, n) asum[i + 1] += asum[i] + a[i];
	FOR(i, m){
		int l = -1, r = n;
		while (r - l != 1) {
			int md = (r + l) / 2;
			if (b[i] >= a[md]) l = md;
			else r = md;
		}
		puts(asum[r] >= c[i] ? "Yes" : "No");
	}
}