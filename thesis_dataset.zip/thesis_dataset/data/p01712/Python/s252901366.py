from itertools import accumulate
n, w, h = map(int, input().split())
xlst = [0] * (w + 1)
ylst = [0] * (h + 1)
for _ in range(n):
  x, y, width = map(int,input().split())
  xlst[max(0, x - width)] += 1
  ylst[max(0, y - width)] += 1
  xlst[min(w, x + width)] -= 1
  ylst[min(h, y + width)] -= 1

accx = list(accumulate(xlst))[:-1]
accy = list(accumulate(ylst))[:-1]
if 0 not in accx or 0 not in accy:
  print("Yes")
else:
  print("No")

