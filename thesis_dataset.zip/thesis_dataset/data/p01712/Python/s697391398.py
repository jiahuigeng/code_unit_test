n,w,h = map(int,input().split())
Yoko = [0] * w
Tate = [0] * h
for i in range(n):
    x,y,r = map(int,input().split())
    for j in range(x - r,x + r):
        if j < w:
            Yoko[j] += 1
    for j in range(y- r,y + r):
        if j < h:
            Tate[j] += 1

if Yoko.count(0) == 0 or Tate.count(0) == 0:
    print("Yes")
else:
    print("No")