#include<bits/stdc++.h>
#define MOD 1000000007
#define allof(a) (a).begin(),(a).end()
using namespace std;

const double EPS = 1e-9;
const int INF = 1L << 30;
vector<int> dx = {0,1,0,-1};
const int dy[4] = {-1,0,1,0};

bool in_range(int x, int lb, int ub) {return lb <= x and x < ub;}
bool in_range(int x, int y, int W, int H) {return in_range(x,0,W) and in_range(y,0,H);}
void modAdd(int &a, int b, int mod) {a = (a + b) % MOD;}
template <typename T> void maxUpdate(T& a, T b){a = max(a,b);}


int main() {
	
	int N,W,H; cin >> N >> W >> H;

	vector<int> X(W+1);
	vector<int> Y(H+1);
	for (int i = 0; i < N; i++) {
		int x,y,w; cin >> x >> y >> w;
		X[max(0,x-w)]++, X[min(W,x+w)]--;
		Y[max(0,y-w)]++,Y[min(H,y+w)]--;
	}

	int x_sum = 0;
	bool x_flg = false;
	for (int i = 0; i < W; i++) {
		x_sum += X[i];
		if (x_sum <= 0) {
			x_flg = true;
		}
	}
	int y_sum = 0;
	bool y_flg = false;
	for (int i = 0; i < H; i++) {
		y_sum += Y[i];
		if (y_sum <= 0) {
			y_flg = true;
		}
	}
	if (x_flg and y_flg) {
		cout << "No" << endl;		
	}else {
		cout << "Yes" << endl;
	}

	return 0;
}