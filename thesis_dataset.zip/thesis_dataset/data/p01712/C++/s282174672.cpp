#include <iostream>
using namespace std;
int main(){

  int n,w,h,x,y,haba,w1[200000]={0},h1[200000]={0},i;

  cin>>n>>w>>h;

  for(i=0;i<n;i++){

    cin>>x>>y>>haba;

    for(int j=x-haba;j<=x+haba;j++) if(0<=j && j<=w) w1[j]=1;
    for(int j=y-haba;j<=y+haba;j++) if(0<=j && j<=w) h1[j]=1;

  }
  int wa=0,ha=0;
  for(i=0;i<w+1;i++) if(w1[i]==0) wa++;
  for(i=0;i<h+1;i++) if(h1[i]==0) ha++;

  if(wa==0 || ha==0) cout<<"Yes"<<endl;
  else cout<<"No"<<endl;

  return 0;

}