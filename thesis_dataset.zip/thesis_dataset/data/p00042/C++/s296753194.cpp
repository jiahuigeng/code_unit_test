#include<bits/stdc++.h>
using namespace std;
int dp[1001][1001],wait[1001],value[1001],dpp[1001][10000];
void Initialization()
{
    for(int i=0;i<1001;i++)for(int j=0;j<1001;j++)dp[i][j]=-1;
    for(int i=0;i<1001;i++)for(int j=0;j<10000;j++)dpp[i][j]=-1;
}
int power(int n)
{
    int num=1;
    for(int i=1;i<=n;i++)num*=10;
    return num;
}
int serch(int i,int j,int n)
{
    int num;
    if(dp[i][j]>-1)return dp[i][j];
    else if(i==n)num=0;
    else if(j<wait[i])num=serch(i+1,j,n);
    else num=max(serch(i+1,j,n),serch(i+1,j-wait[i],n)+value[i]);
    return dp[i][j]=num;
}
int wserch(int i,int va,int ser,int n,int w)
{
    int num;
    if(dpp[i][va]>-1)return dpp[i][va];
    else if(i==n)num=w;
    else if(ser<va+value[i])num=wserch(i+1,va,ser,n,w);
    else if(ser==va+value[i])num=wait[i];
    else num=min(wserch(i+1,va,ser,n,w),wserch(i+1,va+value[i],ser,n,w)+wait[i]);
    return dpp[i][va]=num;
}
int main()
{
    int n,w,point,num=1,wai,wa;
    string str;
    while(cin>>w&&w!=0){
        cin>>n;
        for(int i=0;i<n;i++){
            cin>>str;
            value[i]=0;wait[i]=0;
            for(int j=0;;j++){
                if(str[j]==','){
                    for(int k=0;k<j;k++)value[i]+=power(j-k-1)*(str[k]-'0');
                    point=j;
                }
                if(str[j]=='\0'){
                    for(int k=point+1;k<j;k++)wait[i]+=power(j-k-1)*(str[k]-'0');
                    break;
                }
            }
        }
        Initialization();
        point=serch(0,w,n);
        wai=w;
        for(int i=0;i<n;i++){
            if(value[i]<point){
                wa=wserch(i+1,value[i],point,n,w)+wait[i];
                if(wa<wai)wai=wa;
            }
            else if(value[i]==point&&wai>wait[i])wai=wait[i];
        }
        cout<<"Case "<<num<<":\n"<<point<<endl<<wai<<endl;
        num++;
    }
}