class Knapack(object):
    def __init__(self, data, limit):
        self.limit = limit
        data_size = len(data)
        self.C = [[0]*(limit+1) for _ in range(data_size+1)]
        self.data = data[:]

    def solve(self):
        for i in range(1, len(self.data)+1):
            i_value = self.data[i-1][0]
            i_weight = self.data[i-1][1]
            for w in range(1, self.limit+1):
                if i_weight <= w:
                    if i_value + self.C[i-1][w-i_weight] > self.C[i-1][w]:
                        self.C[i][w] = i_value + self.C[i-1][w-i_weight]
                    else:
                        self.C[i][w] = self.C[i-1][w]
                else:
                    self.C[i][w] = self.C[i-1][w]


if __name__ == '__main__':
    # ??????????????\???
    # limit = 50
    # data = [[60, 10], [100, 20], [120, 30], [210, 45], [10, 4]]
    case_no = 1
    while True:
        limit = int(input())
        if limit == 0:
            break
        num_of_items = int(input())
        data = []
        for i in range(num_of_items):
            data.append(list(map(int, input().split(','))))

        # ????????????????????????????§£???
        ks = Knapack(data, limit)
        ks.solve()

        # ???????????¨???
        target = ks.C[len(data)][limit]
        weight = limit
        for w in range(limit, 0, -1):
            if ks.C[len(data)][w] == target:
                weight = w
        print('Case {0}:'.format(case_no))
        print('{0}\n{1}'.format(target, weight))
        case_no += 1