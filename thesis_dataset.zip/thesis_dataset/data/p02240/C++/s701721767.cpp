#include <iostream>
#include <map>
#include <queue>
using namespace std;
int main(){
  int n,m,t1,t2,c[100000]={}; map <int,bool> g[100000];
  cin>>n>>m;
  for(int i=0;i<m;i++){
    cin>>t1>>t2;g[t1][t2]=1;g[t2][t1]=1;
  }
  int l;cin>>l;
  for(int i=0;i<l;i++){
    queue <int> q;
    bool f[100000]={},find=false;
    cin>>t1>>t2;
    if(c[t1]){
      if(c[t1]==c[t2]) cout<<"yes"<<endl;
      else cout<<"no"<<endl;
      continue;
    }
    q.push(t1);f[t1]=true;c[t1]=i+1;
    for(;!q.empty();){
      for(int j=0;j<n;j++) if(g[q.front()][j]&&!f[j]){
          if(j==t2) find=true;
          f[j]=true;c[t2]=i+1;
          q.push(j);
	}
      q.pop();
      if(find) break;
    }
    if(find) cout<<"yes"<<endl;
    else cout<<"no"<<endl;
  }
  return 0;
}