#include<stack>
#include<queue>
#include<string>
#include<vector>
#include<iostream>
#include<algorithm>
using namespace std;
queue<int> Q;
vector<int> G[100000];
bool flag = false;
int s, t;

void a(){
	while (!Q.empty()){
		Q.pop();
		for (int i = 0; i < G[s].size(); i++){
			if (G[s][i] == t){
				flag = true;
				while (!Q.empty()) Q.pop();
				return;
			}
			else {
				Q.push(G[s][i]);
			}
		}
		if(!Q.empty())s = Q.front();
	}
}

int main(){
	int n, m, q;
	cin >> n >> m;

	for (int i = 0; i < m; i++){
		cin >> s >> t;
		G[s].push_back(t); //??£???????????£?????????
	}
	cin >> q;
	for (int i = 0; i < q; i++){
		cin >> s >> t;
		Q.push(s);
		a();
		if (flag) cout << "yes" << endl;
		else cout << "no" << endl;
		flag = false;
	}

	return 0;
}