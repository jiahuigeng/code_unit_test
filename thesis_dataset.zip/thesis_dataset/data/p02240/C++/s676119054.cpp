#include <iostream>
#include <vector>
#include <stack>
using namespace std;

const long MAX = 100000;
const long NIL = -1;

long n;
vector<long> G[MAX];
long color[MAX];

void dfs(long r, long c){
	stack<long> S;
	S.push(r);
	color[r] = c;
	while (!S.empty()){
		long u = S.top();
		S.pop();
		for (long i = 0; i < G[u].size(); i++){
			long v = G[u][i];
			if (color[v] == NIL){
				color[v] = c;
				S.push(v);
			}
		}
	}
}

void assignColor(){
	long id = 1;
	for (long i = 0; i < n; i++) color[i] = NIL;
	for (long u = 0; u < n; u++){
		if (color[u] == NIL) dfs(u, id++);
	}
}

int main(){
	long s, t, m, q;
	cin >> n >> m;
	for (long i = 0; i < m; i++){
		cin >> s >> t;
		G[s].push_back(t);
		G[t].push_back(s);
	}

	assignColor();

	cin >> q;
	for (long i = 0; i < q; i++){
		cin >> s >> t;
		if (color[s] == color[t]) cout << "yes" << endl;
		else cout << "no" << endl;
	}

	return 0;
}