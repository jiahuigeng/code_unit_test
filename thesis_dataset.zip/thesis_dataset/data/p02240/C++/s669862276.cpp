#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#define N_MAX 100000

int search_connection(vector<int> v, int t, stack<int> st);
vector<int> G[N_MAX];

int main()
{
    int n, m, i, s, t, q;
    stack<int> st;

    cin >> n >> m;

    //??£??\??????????????????
    for (i = 0; i < m; i++) {
        cin >> s >> t;
        G[s].push_back(t);
    }

    //??????????????????
    cin >> q;
    for (i = 0; i < q; i++) {
        cin >> s >> t;
        while (st.size() != 0) st.pop();

        st.push(s);
        if ( search_connection(G[s], t, st) )
            cout << "yes" << endl;
        else
            cout << "no" << endl;
    }

    return 0;
}

int search_connection(vector<int> v, int t, stack<int> st) {
    for (auto itr = v.begin(); itr != v.end(); itr++) {
        if (*itr == t)
            return 1;
        else {
            st.push(*itr);
            return (0 || search_connection(G[*itr], t, st));
        }
    }
}