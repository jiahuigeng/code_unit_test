//config = { input: 'tmp', newline: '\r\n' }; // win
config = { input: '/dev/stdin', newline: '\n' }; // linux

line = require('fs').readFileSync(config.input, 'ascii')
  .trim()
  .split(config.newline)
  .map(function (line) { return line.split(' ').map(Number); });

n = line[0][0];
m = line[0][1];
q = line[m+1][0];

adj = new Array(n);
for (i = 0; i < n; i++) adj[i] = [];
for (i = 1; i <= m; i++) {
  adj[line[i][0]].push(line[i][1]);
  adj[line[i][1]].push(line[i][0]);
}

d = new Array(n);
for (i = 0; i < n; i++) d[i] = null;
stack = new Array(n*2);

function dfs(from, stack, adj, d) {
  var sp = 0, cur = from, rest = adj[from].length, next;
  d[from] = from;
  while (sp >= 0) {
    while (rest !== 0) {
      rest--;
      next = adj[cur][rest];
      if (d[next] !== null) continue;
      d[next] = from;
      stack[sp++] = cur;
      stack[sp++] = rest;
      cur = next;
      rest = adj[next].length;
    }
    rest = stack[--sp];
    cur = stack[--sp];
  }
}

for (i = 0; i < n; i++)
  if (d[i] === null) dfs(i, stack, adj, d);

for (i = m+2; i < (m+2) + q; i++)
  console.log((d[line[i][0]] === d[line[i][1]]) ? 'yes' : 'no');