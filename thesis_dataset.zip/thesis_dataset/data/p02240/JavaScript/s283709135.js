(function main() {
  const lines = require('fs').readFileSync('/dev/stdin', 'utf8').trim().split('\n');
  const [n, m] = lines.shift().split(' ').map(Number);
  const adjLists = Array.from(Array(n), () => []);
  const d = [];

  let s, t;
  for (let i = 0; i < m; i++) {
    [s, t] = lines.shift().split(' ').map(Number);
    adjLists[s].push(t);
  }

  function canReach(s, t) {
    let queue, u, v;
    const innerCanReach = (s, t) => {
      queue = [s];
      while ((u = queue.shift()) !== undefined) {
        for (let i = 0; i < adjLists[u].length; i++) {
          v = adjLists[u][i];
          if (v === t) return true;
          queue.push(v);
        }
      }
      return false;
    }
    return innerCanReach(s, t) || innerCanReach(t, s);
  }

  lines.shift();
  console.log(lines.map(l => canReach(...l.split(' ').map(Number)) ? 'yes' : 'no').join('\n'));
})();

