function main(_stdin) {
    const stdin = _stdin.split('\n');
    const [user, relation] = stdin.shift().split(' ');
    const relations = stdin.filter((e, i) => i < relation).map(e => e.split(' ').map(e => parseInt(e, 10)));
    const qblock = stdin.slice(relation);
    const qnum = parseInt(qblock.shift(), 10);
    const questions = qblock.filter((e, i) => i < qnum).map(e => e.split(' ').map(e => parseInt(e, 10)));

    const nodes = createNodes(relations);
    const color = [...new Array(parseInt(user, 10)).keys()].fill(null);

    assignColor(nodes, color);


    for(const q of questions){
        if(color[q[0]] && color[q[1]] && color[q[0]] === color[q[1]]) {
            console.log('yes');
        } else {
            console.log('no');
        }
    }
}

function createNodes(relations) {
    const nodes = [];
    for (let i = 0, l = relations.length; i < l; i++) {
        const [from, to] = relations[i];
        if (!nodes[from]) {
            nodes[from] = [from, 1, to];
        } else {
            nodes[from][1]++;
            nodes[from].push(to);
        }
        if (!nodes[to]) {
            nodes[to] = [to, 1, from];
        } else {
            nodes[to][1]++;
            nodes[to].push(from);
        }
    }
    return nodes;
}

function dfs(nodes, color, r, c) {
    const stack = [];
    stack.push(r);
    color[r] = c;

    while (stack.length !== 0) {
        const u = stack.pop();
        const children = nodes[u].slice(2);
        for (let i = 0, l = children.length; i < l; i++) {
            const v = children[i];
            if (color[v] === null) {
                color[v] = c;
                stack.push(v);
            }
        }
    }
}

function assignColor(nodes, color) {
    let id = 1;
    let max = color.length - 1;
    for (let i = 0; i < max; i++) {
        if (color[i] === null && nodes[i] !== undefined) {
            dfs(nodes, color, i, id++);
        }
    }
}

main(require('fs').readFileSync('/dev/stdin', 'utf8'));

