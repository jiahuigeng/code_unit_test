//config = { input: 'tmp', newline: '\r\n' }; // win
config = { input: '/dev/stdin', newline: '\n' }; // linux

line = require('fs').readFileSync(config.input, 'ascii')
  .trim()
  .split(config.newline)
  .map(function (line) { return line.split(' ').map(Number); });

n = line[0][0];
m = line[0][1];
q = line[m+1][0];

adj = new Array(n);
for (i = 0; i < n; i++) adj[i] = null;

for (i = 1; i <= m; i++) {
  min0 = id0 = line[i][0];
  min1 = id1 = line[i][1];
  while (adj[min0] !== null) min0 = adj[min0];
  while (adj[min1] !== null) min1 = adj[min1];
  min = Math.min(min0, min1);
  if (id0 !== min) adj[id0] = min;
  if (id1 !== min) adj[id1] = min;
}

for (i = m+2; i < (m+2) + q; i++) {
  q0 = line[i][0];
  q1 = line[i][1];
  while (adj[q0] !== null) q0 = adj[q0];
  while (adj[q1] !== null) q1 = adj[q1];
  console.log((q0 === q1) ? 'yes' : 'no');
}