def dfs(s):
    global t
    if s == t:
        return True
    DP[s]=1
    for i in F[s]:
        if not DP[i]:
            if dfs(i):
                return True
    return False
    
n,m = [int(i) for i in input().split()]
F = [{}]*n
for _ in range(m):
    i,j = [int(i) for i in input().split()]
    F[i][j] = 1
q = int(input())
for i in range(q):
    DP = [0]*n
    s,t = [int(i) for i in input().split()]
    if dfs(s):
        print("yes")
    else:
        print("no")
