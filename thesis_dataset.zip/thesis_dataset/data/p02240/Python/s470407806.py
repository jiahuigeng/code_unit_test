def tan(G,st,fi):
    global flag
    for i in range(len(G)):
        if G[st][i] == 1:
            if i == fi:
                flag = 1
            tan(G,i,fi)
    
n,m = list(map(int, input().split()))
G = [[0 for i in range(n)] for j in range(n)]

for i in range(m):
    S = list(map(int, input().split()))
    if S[0]<S[1]:
        G[S[0]][S[1]] = 1
    else:
        G[S[1]][S[0]] = 1

q = int(input())
ans = []
for i in range(q):
    Q = list(map(int, input().split()))
    if Q[0]<Q[1]:
        st = Q[0]
        fi = Q[1]
    else:
        st = Q[1]
        fi = Q[0]
    flag = 0
    tan(G,Q[0],Q[1])
    if flag==1:
        ans.append("yes")
    else:
        ans.append("no")
        
for i in range(q):
    print(ans[i])
