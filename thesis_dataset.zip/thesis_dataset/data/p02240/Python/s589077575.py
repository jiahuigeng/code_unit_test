n, m = map(int, input().split())

a = [[] for i in range(n)]

for i in range(m):
    com = list(map(int, input().split()))
    a[com[0]].append(com[1])
    a[com[1]].append(com[0])

q = int(input())

from collections import deque
queue = deque()


for j in range(q):
    memo = [0 for i in range(n)]
    data = list(map(int, input().split()))
    memo[data[0]] = 1
    queue.append(data[0])

    try:
        while len(queue) != 0:
            b = queue.popleft()
            if len(a[b]) != 0:
                for k in a[b]:
                    if memo[k] == 0:
                        memo[k] = 1
                        queue.append(k)
                        if k == data[1]:
                            print("yes")
                            raise Exception
        print("no")
    except Exception:
        pass
