#coding:utf-8

def CC(root,dist):
    for i in range(len(dist)):
        if i==root[0]:
            dist[i]=dist[i]+[root[1]]
        elif i==root[1]:
            dist[i]=dist[i]+[root[0]]
        
def Check(dist,start,end,clist):
    ans="no"
    if len(dist[end])!=0:
        if start in dist[end]:
            ans="yes"
        else:
            clist.append(end)
            for d in dist[end]:
                if d!=end and d not in clist:
                    ans=Check(dist,start,d,clist)
    return ans
    
if __name__=="__main__":
    I=input()
    n=int(I.split(" ")[0])
    m=int(I.split(" ")[1])
    A=[]
    for i in range(m):
        A.append(list(map(int,input().split(" "))))
    dist=[[]]*n
    for i in range(m):
        CC(A[i],dist)
    q=int(input())
    for i in range(q):
        qList=list(map(int,input().split(" ")))
        print(Check(dist,qList[0],qList[1],[]))