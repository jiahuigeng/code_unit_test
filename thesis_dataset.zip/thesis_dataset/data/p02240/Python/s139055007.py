def bfs(s, t):
  q = [s]
  while len(q) > 0:
    v = q.pop(0)
    if v == t: return True
    if len(G[v]) > 0:
      q.extend(sorted(G[v]))
      G[v] = []
  return False

u, n = map(int, input().split())
G = [[] for _ in range(u)]
for _ in range(n):
  a, b = map(int, input().split())
  if b not in G[a]: G[a].append(b)
  if a not in G[b]: G[b].append(a)

q = int(input())
for _ in range(q):
  s, t = map(int, input().split())
  if bfs(s, t):
    print("yes")
  else:
    print("no")