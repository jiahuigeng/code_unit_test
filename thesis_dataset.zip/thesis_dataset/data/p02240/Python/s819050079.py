#coding:utf-8

def CC(root,dist):
    Flag=False
    if len(dist)!=0:
        for i in range(len(dist)):
            if dist[i][-1]==root[0]:
                d=dist[i]
                d=d+[root[1]]
                dist.append(d)
                Flag=True
            elif dist[i][-1]==root[1]:
                d=dist[i]
                d=d+[root[0]]
                dist.append(d)
                Flag=True
    if Flag==False:
        dist.append(root)

def Check(dist,qList):
    for i in range(len(dist)):
        if qList[0] in dist[i] and qList[1] in dist[i]:
            return "yes"
    return "no"
    
if __name__=="__main__":
    I=input()
    n=int(I.split(" ")[0])
    m=int(I.split(" ")[1])
    A=[]
    for i in range(m):
        A.append(list(map(int,input().split(" "))))
    dist=[]
    for i in range(m):
        CC(A[i],dist)
    q=int(input())
    for i in range(q):
        print(Check(dist,list(map(int,input().split(" ")))))