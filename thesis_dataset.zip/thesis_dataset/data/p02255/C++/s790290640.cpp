#include<iostream>
#include<algorithm>
using namespace std;

int main() {
	int n;
	int a[10000];
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}
	cout << a[0] << " " << a[1] << " " << a[2] << " " << a[3] << " " << a[4] << " " << a[5] << endl;
	for (int i = 0; i < n - 1; i++) {
		sort(a, a + i + 2);
		cout << a[0] << " " << a[1] << " " << a[2] << " " << a[3] << " " << a[4] << " " << a[5] << endl;
	}
	cin >> n;
}