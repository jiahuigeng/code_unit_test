#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <algorithm>
#include <cstdio>
#include <cmath>
using namespace std;
void insert(int a[],int n){
	for(int i=1;i<=n;i++){
		if(i>1)cout<<" ";
		cout<<a[i];
	}
	cout<<endl;
}
int main(){
	int n;
	int a[100];
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	insert(a,n);
	for(int j=2;j<=n;j++){
		int v=a[j];
		int i=j-1;
		while(i>=0&a[i]>v){
			a[i+1]=a[i];
			i--;
		}
		a[i+1]=v;
		insert(a,n);
	}

	return 0;
}