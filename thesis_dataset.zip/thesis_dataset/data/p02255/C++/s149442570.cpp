#include <bits/stdc++.h>
using namespace std;

int main() {
  int N;
  cin >> N;
  vector<int> A(N);
  for (int i=0; i<N; i++) cin >> A[i];

  for (int i=1; i<N; i++) {
    printf("%d %d %d %d %d %d\n", A[0], A[1], A[2], A[3], A[4], A[5]);
    int v = A[i];
    int j = i - 1;
    while (j >= 0 && A[j] > v) {
      A[j+1] = A[j];
      j--;
    }
    A[j+1] = v;
  }

  printf("%d %d %d %d %d %d\n", A[0], A[1], A[2], A[3], A[4], A[5]);

  return 0;
}

