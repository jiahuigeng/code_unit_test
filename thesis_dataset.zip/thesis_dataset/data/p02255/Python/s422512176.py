n = int(input())
a = input().split()
def insertionSort(ary,num):
    for i in range(n):
        v = a[i]
        j = i - 1
        while j >= 0 and a[j] > v:
            a[j+1] = a[j]
            j -= 1 
        a[j+1] = v
        print(" ".join(a).rstrip())

insertionSort(a,n)