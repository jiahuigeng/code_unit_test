var input = require('fs').readFileSync('/dev/stdin', 'utf8').trim().split('\n');
var n = +input.shift();
var nums = input.shift().split(' ').map(Number);

function insertion_sort(numbers) {
  for (var i = 0; i < numbers.length; i++) {
    var key = numbers[i];
    var j = i - 1;
    while (j >= 0 && numbers[j] > key) {
      numbers[j + 1] = numbers[j];
      j--;
    }
    numbers[j + 1] = key;
    console.log(numbers.join(' '));
  }
}

insertion_sort(nums);