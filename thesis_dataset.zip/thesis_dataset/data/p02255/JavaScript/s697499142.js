function main() {
  var N = input[0];
  var A = input[1].split(' ').map(function (x) {
    return parseInt(x, 10);
  });
  var v;
  for (var i = 0; i < N; i++) {
    v = A[i];
    for (var j = i - 1; j >= 0; j--) {
      if (A[j] > v) {
        A[j + 1] = A[j];
      } else {
        break;
      }
    }
    A[j + 1] = v;
    console.log(A.join(' '));
  }
}

var input = '';
process.stdin.resume();
process.stdin.setEncoding('utf8');
process.stdin.on('data', function(chunk) {
  input += chunk;
});
process.stdin.on('end', function() {
  input = input.split('\n');
  input.pop();
  main();
});