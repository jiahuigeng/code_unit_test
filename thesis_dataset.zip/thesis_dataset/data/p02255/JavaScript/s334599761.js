function main(input) {
  const args = input.split('\n');
  num = Number(args[0])

  arr = args[1].split(' ').map(n => Number(n))

  console.log(arr.join(' '))
  insertionSort(num, arr)

}

function insertionSort(length, arr) {

  for (let i = 1; i < length; i++) {
    let v = arr[i]
    let j = i - 1
    while (j >= 0 && arr[j] > v) {
      arr[j+1] = arr[j]
      j--
    }
    arr[j+1] = v
    console.log(arr.join(' '))
  }
}


main(require('fs').readFileSync('/dev/stdin', 'utf8'));

