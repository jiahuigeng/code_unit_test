l=[list(map(int,input().split())) for _ in range(int(input()))]
l=sorted(l,key=lambda x:x[0])
m=[0 for i in range(100002)]
c=1
for i in l:
    if i[0]<=c+1:
        m[i[0]]+=1
        m[i[1]]-=1
        c+=1
for i in range(2,100001):
    m[i]+=m[i-1]
print(max(m))

