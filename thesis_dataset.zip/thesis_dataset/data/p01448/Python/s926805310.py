n = int(input())
a = [0] * (10**5 + 2)
for i in range(n) :
    mi, ma = map(int, input().split())
    a[mi-1] += 1
    a[ma] -= 1
for i in range(n) :
    a[i+1] += a[i]
    
ans = 0
for i in range(n, 0, -1) :
    if a[i] >= i :
        ans = i
        break
print(ans)
