#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

int n;
int cnt[100005];

int main()
{
    cin >> n;
    int a, b;
    for(int i = 0; i < n; i++){
        cin >> a >> b;
        for(int j = a; j < b + 1; j++){
            cnt[j]++;
        }
    }

    int ans = 0;
    for(int i = 1; i < n + 2; i++){
        if(i <= cnt[i] + 1) ans = cnt[i] - 1;
    }
    cout << ans << endl;
    return 0;
}
