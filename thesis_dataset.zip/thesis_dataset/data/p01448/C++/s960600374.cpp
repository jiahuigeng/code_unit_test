#include <bits/stdc++.h>
using namespace std;

int memo[100006] = {0};
int n, ans;

int main() {
  int i, a, b;
  cin >> n;
  for(i = 0; i < n; ++i) {
    cin >> a >> b;
    ++memo[a];
    --memo[b + 1];
  }
  for(i = 1; i <= 100002; ++i) {
    memo[i] += memo[i - 1];
    if(i <= memo[i] + 1) ans = i - 1;
  }
  cout << ans << endl;
  return 0;
}
