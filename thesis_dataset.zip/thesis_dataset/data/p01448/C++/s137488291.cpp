#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;cin>>n;
    vector<int> k(100002);
    int ma=0;
    for(int i=0;i<n;i++){
        int a,b;cin>>a>>b;
        ma=max(ma,b);
        k[a-1]--;
        k[b]++;
    }
    int count=1;
    for(int i=ma;i>=0;i--){
        count+=k[i];
        if(count>=i){
            count=i;break;
        }
    }
    cout<<count-1<<endl;
}

