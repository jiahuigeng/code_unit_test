#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;


int main(){
	int n;
	int a[100001], b[100001];

	a[0] = 0; b[0] = 100001;
	cin >> n;
	int max = 0, min = 100001;
	for (int i = 0; i < n; ++i){
		cin >> a[i] >> b[i];
		if (a[i] < min) min = a[i];
		else if (b[i] > max) max = b[i];
	}

	int max_friends = 0;
	for (int i = min; i < max+1; ++i){
		int friends = 0;
		for (int j = 0; j < n; ++j){
			if (a[j] <= i && b[j] >= i){
				++friends;
//				cout << i << a[j] << b[j] << "OK" << endl;
			}
			else{
//				cout << i << a[j] << b[j] << "NG" << endl;

			}
		}
		if ((friends) == i){
			max_friends = i-1;
		}
	}

	cout << max_friends << endl;



	return 0;
}