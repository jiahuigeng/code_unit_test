#include <bits/stdc++.h>

using namespace std;

#define rep(i,x) for(int i=0;i<x;++i)
#define all(a) begin(a),end(a)

signed main()
{
    string S; cin >> S;

    int N = S.size();

    int J = 0, O = 0, I = 0;

    int ans = 0;

    rep(i, N) {
        if (S[i] != 'J') {J=O=I=0;continue;}
        while (S[i] == 'J') {
            J++;
            i++;
            O = I = 0;
        }
        if (S[i] != 'O') {J=O=I=0;i--;continue;}
        while (S[i] == 'O') {
            O++;
            i++;
            I = 0;
        }
        if (S[i] != 'I') {J=O=I=0;i--;continue;}
        while (S[i] == 'I') {
            I++;
            i++;
            if (O <= J && O <= I) ans = max(ans, O);
        }
        J=O=I=0;
        i--;
    }

    cout << ans << endl;
}