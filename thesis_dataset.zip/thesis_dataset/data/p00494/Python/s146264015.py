s=input()
i=0
maxlv=0
while i<len(s):
    lbuf=0
    if s[i]=='J':
        j=1
        while i+j<len(s) and s[i+j]=="J":j+=1
        lbuf=j
        i=i+j
        j=0
        while i+j<len(s) and j<=lbuf and s[i+j]=="O":j+=1
        lbuf=min((lbuf,j))
        if lbuf==0:continue
        i=i+j
        j=0
        while i+j<len(s) and j<=lbuf and s[i+j]=="I":j+=1
        lbuf=min((lbuf,j))
        if lbuf==0:continue
        elif lbuf>maxlv:
            maxlv=lbuf
            i=i+j
    else:i+=1
print(maxlv)