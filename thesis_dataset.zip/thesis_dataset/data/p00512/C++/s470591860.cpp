#include <iostream>
#include <cstdio>
#include <map>
#include <string>
#include <vector>
#include <algorithm>




using namespace std;




bool cmp(const pair<string, int>& x, const pair<string, int>& y)
{
	if (x.first.size() != y.first.size()){
		return x.first < y.first;
	}
	return x.first.size() < y.first.size();
}




int main()
{
	map<string, int> m;
	string pn;
	int n, c;




	scanf("%d", &n);
	
	for (int i = 0; i < n; i++){
		cin >> pn >> c;




		if (m.count(pn)) m[pn] += c;
		else m.insert(make_pair(pn, c));
	}




	vector< pair<string, int> > v;




	for (map<string, int>::iterator it = m.begin(); it != m.end(); it++){
		v.push_back(*it);
	}




	sort(v.begin(), v.end(), cmp);




	for (vector< pair<string, int> >::iterator it = v.begin(); it != v.end(); it++){
		cout << it->first << " " << it->second << endl;
	}




	return (0);
}