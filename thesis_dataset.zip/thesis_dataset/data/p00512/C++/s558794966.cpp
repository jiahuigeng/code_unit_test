#include<iostream>
#include<map>
using namespace std;main(){map<string,int>h;map<string,int>::iterator t;int n;string s;for(cin>>n;cin>>s>>n;)h[s]+=n;for(n=0;n++<5;)for(t=h.begin();t!=h.end();t++)if(t->first.size()==n)cout<<t->first<<" "<<t->second<<"\n";}