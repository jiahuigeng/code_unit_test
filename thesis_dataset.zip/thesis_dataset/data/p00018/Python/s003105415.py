print(*reversed([int(e)for e in input().split()]))
