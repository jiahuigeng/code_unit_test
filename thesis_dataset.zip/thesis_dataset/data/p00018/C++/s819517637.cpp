#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main(){
	char ch[5];
	for( int i = 0; i < 5; i++ ){
		cin >> ch[i];
	}
	sort(ch, ch+5, greater<int>());
	for( int i = 0; i < 4; i++ ){
		cout << ch[i] << " ";
	}
	cout << ch[4] << endl;
}