#include <iostream>

using namespace std;

/*
 * unsinged long long?????¨???????????¨??§???????????????????????????????????????????????? mod (2<<64)??¨??????????????¨????????????
 * P????????¨????????????(2<<64)??¨?´???§???????????????????????§????????????????????¶
 */
typedef unsigned long long ull;

#define P1 (63533)
#define P2 (100007)

#define H (1000)
#define W (1000)
#define R (1000)
#define C (1000)
char str[H][W];
char pat[R][C];
ull str_hash[H][W];
ull tmp[H][W];

void rolling_hash(int height, int width, char character[H][W])
{

    ull pow = 1;
    ull hash;
    
    for (int i=0; i < width; i++){
        pow *= P1;
    }
    
    for (int i=0; i + height < H; i++) {
        
        hash = 0;
        for (int j = 0; j < width; j++){
            hash = hash * P1 + character[i][j];
        }
        
        for (int j = 0; j + width <= W; j++) {
            tmp[i][j] = hash;
            if (j + width < W) {
                hash = hash * P1 + character[i][j + width] - pow * character[i][j];
            }
        }
    }
    
    pow = 1;
    for (int i=0; i < height; i++){
         pow *= P2;
    }
    
    for (int j=0; j + width <= W; j++) {
        
        hash = 0;
        for (int i = 0; i < height; i++){
            hash = hash * P2 + tmp[i][j];
        }
        
        for (int i = 0; i + height <= H; i++) {
            str_hash[i][j] = hash;
            if(i + height < H){
                hash = hash * P2 + tmp[i + height][j] - pow * tmp[i][j];
            }
        }
    }
    
    return;
}

int main(){
    
    ull pat_hash;
    int sh, sw, ph, pw;
    char c;
    
    cin >> sh >> sw;
    for(int i = 0; i < sh; i++){
        for (int j = 0; j < sw; j++) {
            cin >> c;
            str[i][j] = c;
        }
    }
    
    cin >> ph >> pw;
    for(int i = 0; i < ph; i++){
        for (int j = 0; j < pw; j++) {
            cin >> c;
            pat[i][j] = c;
        }
    }
    
    rolling_hash(ph, pw, pat);
    pat_hash = str_hash[0][0];
    rolling_hash(ph, pw, str);
    
    for(int i = 0; i <= sh; i++){
        for (int j = 0; j <= sw; j++) {
            if (pat_hash == str_hash[i][j]) {
                cout << i << " " << j <<endl;
            }
        }
    }
    
    return 0;
}