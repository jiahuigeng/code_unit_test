CSIZE = 256

def make_bm_table(pattern,size):
    bm_table = [size]*CSIZE
    for i in range(size):
        dist = size-i-1
        charac = pattern[i]
        bm_table[ord(charac)] = dist
    return bm_table

def bm_search(pattern,buff): 
        size = C
        bm_table = make_bm_table(pattern[0], size)    
        buffsize = W
        for j in range(H-C):
            saikobi = size-1
            while saikobi < buffsize:
                for i in range(size):
                    if pattern[0][size-i-1] != buff[j][saikobi-i]:
                        saikobi += max(bm_table[ord(buff[j][saikobi-i])]-i,1)
                        break
                else:
                    count = 1
                    for k in range(1,R):
                        for l in range(C)[::-1]: 
                            if pattern[k][size-1-l] != buff[j+k][saikobi-l]:
                                count = 0
                                break
                        if count == 0:
                            break
                    else:
                        print(j,saikobi-C+1)
                    saikobi += 1  
                    
            

H,W = map(int,input().split())
buff = [""]*H
for i in range(H):
    buff[i] = input()
    
R,C = map(int,input().split())
pattern = [""]*R
for i in range(R):
    pattern[i] = input()  


bm_search(pattern, buff)                