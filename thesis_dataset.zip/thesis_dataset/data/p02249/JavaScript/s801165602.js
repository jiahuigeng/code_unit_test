//config = { input: 'tmp', newline: '\r\n' }; // win
config = { input: '/dev/stdin', newline: '\n' }; // linux
 
line = require('fs').readFileSync(config.input, 'ascii')
  .split(config.newline);
line[0] = line[0].split(' ').map(Number);
H = line[0][0];
W = line[0][1];
field = line.slice(1, 1+H);
line[1+H] = line[1+H].split(' ').map(Number);
R = line[1+H][0];
C = line[1+H][1];
pat = line.slice(1+H+1, 1+H+1+R);
 
if (H < R || W < C) process.exit();
 
hash = {};
cnt = 1;
function register(str) {
  if (!hash.hasOwnProperty(str)) {
    hash[str] = cnt;
    return cnt++;
  }
  return hash[str];
}
pat = pat.map(register);
 
matrix = field.map(function (str) {
  var res, i, sliced;
  res = [];
  for (i = 0; i <= W-C; i++)
    res.push(hash[str.slice(i, i+C)] || 0); // safe because returns undefined
  return res;
});

function transpose(matrix) {
  var res = [], rows = matrix[0].length, cols = matrix.length, i, row, j;
  for (i = 0; i < rows; i++) {
    row = [];
    for (j = 0; j < cols; j++) row.push(matrix[j][i]);
    res.push(row);
  }
  return res;
}
matrix = transpose(matrix);

matrix = matrix.map(function (row) {
  return row.map(function (num) { return num.toString(36); }) });

function makeJoinSeries(ary) {
  var res, i;
  res = [];
  for (i = 0; i <= ary.length - R; i++)
    res.push(ary.slice(i, i+R).join(' '));
  return res;
}
matrix = matrix.map(makeJoinSeries);

patHash = {};
patHash[makeJoinSeries(pat)] = true;
matrix = matrix.map(function (row) {
  return row.map( function (str) { return patHash[str] || false; });
});

matrix = transpose(matrix);

for (i in matrix)
  for (j in matrix[i])
    if (matrix[i][j]) console.log('%s %s', i, j);