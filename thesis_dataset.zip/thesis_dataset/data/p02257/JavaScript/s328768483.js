// a^b = a^{2^k1} * a^{2^k2} * ... *a^{2^i} * ...であることを利用して冪剰余を計算する。
// たとえばa^22 = a^16 * a^4 * a^2(22は２進数で100110) 
function modPow(a, b, n) {
    let d = 1;
    while (b > 0) {
        if (b & 1) {       // 最下位ビットが立っているときにa^(2^i)を掛ける。
            d = (d * a) % n;
        }
        a = (a * a) % n;
        b >>= 1;
    }
    return d;
}

function witness(a, n, t, u) {
    let x = modPow(a, u, n);  // x0 = a^u mod nを計算
    let y = x;

    for (let i = 0; i < t; i++) {
        y = (x * x) % n;

        // 法nの下での1の非自明な平方根が存在するのはnが合成数であるときに限る
        if (y === 1 && x !== 1 && x !== (n - 1)) {
            return true;
        }
        x = y;
    }
    return y !== 1;
}

function isProbablyPrime(n, witnesses) {
    let t = 1
    let u = Math.floor(n / 2);
    while (!(u & 1)) {
        t = t + 1;
        u = Math.floor(u / 2);
    }

    for (let a of witnesses) {
        if (a % n !== 0 && witness(a, n, t, u)) {
            return false;
        }
    }
    return true;
}

function isDefinitelyPrime(n) {
    if (((!(n & 1)) && n !== 2) || (n < 2) || ((n % 3 === 0) && (n !== 3))) { 
        return false;
    }
    if (n <= 3) {
        return true; 
    }
    return isProbablyPrime(n, [2, 7, 61]);
}

// inputに入力データ全体が入る
function main(input) {
	// 1行目がinput[0], 2行目がinput[1], …に入る
    input = input.split("\n");
    
    let answer = 0;
    const n = parseInt(input[0], 10);
    for (let i = 0; i < n; i++) {
        if (isDefinitelyPrime(parseInt(input[i + 1], 10))) {
            answer++;
        }
    }
    console.log(answer);
}
//*この行以降は編集しないでください（標準入出力から一度に読み込み、Mainを呼び出します）
main(require("fs").readFileSync("/dev/stdin", "utf8"));
