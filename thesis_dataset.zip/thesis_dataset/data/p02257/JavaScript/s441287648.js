(function(input) {
    var p = input.split('\n').map(Number);
    var n = p.shift();
    var a = p.slice(0, n);
    var pns = primeNumbersIn(a);
    console.log(pns.length);
})(require('fs').readFileSync('/dev/stdin', 'utf8'));

function greatestCommonDevisor(x, y) {
    return Math.max.apply(null, commonDevisors(x, y));
}

function commonDevisors(x, y) {
    if (x > y) {
        x = x % y;
    } else if (x < y) {
        var tmp = y;
        y = x;
        x = tmp % x;
    }
    var a = [];
    var ds = divisors(x);
    for (var i = 0; i < ds.length ; i++) {
        var d = ds[i];
        if (y % d === 0) {
            a.push(i);
        }
    }
    return a;
}

function divisors(x) {
    var a = [];
    for (var i = 1; i <= x; i++) {
        if (x % i === 0) {
            a.push(i);
        }
    }
    return a;
}

function isPrimeNumber(x) {
    if (x < 2) {
        return false;
    }
    for (var i = 2; i < x; i++) {
        if (x % i === 0) {
            return false;
        }
    }
    return true;
}

function inArray(needle, heystack) {
    return heystack.indexOf(needle) !== -1;
}

function primeNumbersIn(a) {
    a = a.sort(function(a, b) {
        return a - b;
    });
    var t = 0;
    var n = a[t];
    do {
        for (var i = n * 2; i <= Math.max.apply(null, a); i += n) {
            var index = a.indexOf(i);
            if (index > -1) {
                a = a.slice(0, index).concat(a.slice(index + 1, a.length));
            }
        }
        n = a[++t];
    } while (n < Math.sqrt(Math.max.apply(null, a)))
    return a;
}