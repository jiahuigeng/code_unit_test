(() => {

    var lines = [];

    require('readline').createInterface({
        input: process.stdin,
    }).on('line', (line) => {
        lines.push(parseInt(line, 10));
    });

    process.stdin.on("end", function(){
        console.log(lines.filter(isPrime).length);
    });

    const isPrime = function(x){
        if(x == 2){
            return true;
        }

        if(x < 2 || (x & 0x01) === 0){
            return false;
        }

        const sqrt_x = Math.sqrt(x);
        for(let i = 3; i <= sqrt_x; i+=2){
            if(x % i === 0){
                return false;
            }
        }
        return true;
    }


})();
