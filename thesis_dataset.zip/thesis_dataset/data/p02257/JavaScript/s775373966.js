// 試し割り法による素数判定
function is_prime(n) {
    for (let i = 2; i * i <= n; i++) {
        if (n % i === 0) {
            return false;
        } 
    }
    return n !== 1;  // 1は素数ではないことに注意。
}

// inputに入力データ全体が入る
function Main(input) {
	// 1行目がinput[0], 2行目がinput[1], …に入る
    input = input.split("\n");
    
    let answer = 0;
    const n = parseInt(input[0], 10);
    for (let i = 0; i < n; i++) {
        if (is_prime(parseInt(input[i + 1], 10))) {
            answer++;
        }
    }
    console.log(answer);
}
//*この行以降は編集しないでください（標準入出力から一度に読み込み、Mainを呼び出します）
Main(require("fs").readFileSync("/dev/stdin", "utf8"));
