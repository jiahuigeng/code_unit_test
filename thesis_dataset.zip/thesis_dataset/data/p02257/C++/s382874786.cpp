#include<iostream>
#include <math.h>
using namespace std;
 

int prime(int p,int d){
	return d?prime(p,p%d):p;
}
 
main(){
  int n,m,i=0,t=0;
  cin >> n;
  int x[n];
  while(cin >> x[i]) i++;
  
  for (int i = 0; i < n; i++){
  	if(x[i] == 2) t++;
  	
  	m = pow(2,x[i]-1);
  	if(m%x[i] == 1) t++;
  }
  cout << t << endl;
  
return 0;
}