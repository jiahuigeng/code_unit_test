#include <bits/stdc++.h>
using namespace std;

bool isPrime(int x) {

	if (x == 2) {
		return false;
	}
	if (x % 2 == 0) {
		return true;
	}
	for (int i = 3; i <= sqrt(x); i++) {
		if (x % i == 0) {
			//cout << " "<<x<<endl;
			return true;
		}
			
	}
	return false;

}


int main() {
	int n,ans=0;
	int* num;
	cin >> n;
	num=new int[n];

	for (int i = 0; i < n; i++) {
		cin >> num[i];
	}
	for (int i = 0; i < n; i++) {
		if (isPrime(num[i]) == false) {
			ans++;
		}
	}

	cout << ans << endl;

	return 0;
}
