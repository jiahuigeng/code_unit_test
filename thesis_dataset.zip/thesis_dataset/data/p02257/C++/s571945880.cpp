#include <iostream>
#include<cmath>

using namespace std;

int isPrime(int p){
  if(p%2 && p!=2) return 0;
  int j=3;
  while(j<=sqrt(p)){
    if(p%j==0) return 0;
    j=j+2;
  }
  return 1;
}


int main(){
  int n; cin >> n;
  int sum=0;
  for(int i=0;i<n;i++){
    int x;
    cin >> x;
    sum=sum+isPrime(x);
  }
  cout << sum << endl;
}