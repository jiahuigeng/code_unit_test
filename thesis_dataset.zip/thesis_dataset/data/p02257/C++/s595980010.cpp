#include <iostream>
#include <cmath>

using namespace std;
bool isPrime(int num){
    if(num==1)return false;
    if(num==2)return true;
    if(num%2==0)return false;
    int s=(int)log2(num-1);
    int d=num-1;
    for(int i=0;i<s;i++){
        d/=2;
    }
    int n=min(num-1,(int)(2*(log(num))*(log(num))));
    int l[3]={2,7,61};
    for(int a=0;a<3;a++){
        int ad=l[a];
        for(int j=0;j<d;j++){
            ad*=d;
        }
        if(ad%num==1)return true;
        for(int j=0;j<s;j++){
            ad*=2;
            if(ad%num==num-1)return true;
        }
    }
    return false;
}
int main(){
    int n;
    cin >> n;
    int count=0;
    for(int i=0;i<n;i++){
        int a=0;
        cin >> a;
        if (isPrime(a)){
            count++;
        }
    }
    cout << count << endl;
    return 0;
}
