#include <iostream>
#include <math.h>

using namespace std;

bool isPrime(int &num){
    if(num == 2){
        return true;
    }else if(num % 2 == 0){
        return false;
    }else{
        int numHalf = sqrt(num);
        for(int i=3 ; i <= numHalf;i += 2){
            if(num % i == 0){
                return false;
            }
        }
    }
    return true;
}

int main(){
    int N;
    int ans = 0;
    cin >> N;
    for(int i=0;i<N;i++){
        int val;
        cin >> val;
        if(isPrime(val)) ans ++;
    }
    cout << ans << endl;
    return 0;
}
