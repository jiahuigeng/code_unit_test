#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <complex>
#include <stack>
#include <queue>
#include <list>
#include <utility>
#include <map>
#include <set>
using namespace std;

int prime(int n){
    int flag = 1;
    int i;
    
    for(i = 2; i <= sqrt(n); i++){
        if(n%i == 0){
            flag = 0;
        }
    }
    
    return flag;
}

int main(){
    int count = 0;
    int i = 0;
    int a;
    int n;
    cin >> n;
    
    for(i = 0; i < n; i++){
        cin >> a;
        if(prime(a)){
            count++;
        }
    }
    
    cout << count << endl;
}
