#include <iostream>
using namespace std;

int main()
{
  int N;
  cin >> N;

  int num[ N ];
  for( int i = 0; i < N; i++ ) {
    cin >> num[ N ];
  }

  for( int i = 0; i < N; i++ ) {
    for( int j = i + 1; j < N; j++ ) {
      if( num[ j ] * num[ i ] != 0 and num[ j ] % num[ i ] == 0 ) {
        num[ j ] = 0;
      }
    }
  }

  int cnt = 0;
  for( int i = 0; i < N; i++ ) {
    if( num[ i ] != 0 ) {
      cnt += 1;
    }
  }

  cout << cnt << endl;

  return 0;
}

