#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
using ll=long long;
const int MAX = (int)1e7;
bool prime[MAX + 1];

int main() {
	fill(prime, prime + MAX + 1, 1);
	for (int i = 2; i <= MAX; i++) {
		if (prime[i]) {
			for (int k = 2; i*k <= MAX; k++) {
				prime[i*k] = 0;
			}
		}
	}
	int n;
	int a;
	int cnt = 0;
	scanf("%d", &n);
	bool isPrime = 1;
	for (int i = 0; i < n; i++) {
		scanf("%d", &a);
		if (a <= (int)1e7) {
			cnt += prime[a];
		}
		else {
			int bd = sqrt(a)+1;
			isPrime = 1;
			for (int i = 2; i <= bd; i++) {
				if (a%i == 0) {
					isPrime = 0;
					break;
				}
			}
			cnt += isPrime;
		}
	}
	cout << cnt << endl;
}