N=int(input())
A=[]
for i in range(N):
    A.append(int(input()))
count=0
for i in range(len(A)):
    if A[i]<2:
        continue
    elif A[i]==2:
        count += 1
        continue
    if A[i]%2==0:
        continue
    elif A[i]>=3:
        j=3
        flag=0
        while j<=A[i]/j:
            if A[i]%j==0:
                flag=1
                break
            j += 2
        if flag==0:
            count += 1
print(count)
