def division(x,y):
    if y == 0:
        return x
    return  division(y, x%y)

def checker(x):
    for i in range(2,x//2+1):
        v = division(x,i)
        if v > 1 :
            return False
        else:
            return True

cnt=0
q=int(input())
for i in range(q):
    o=checker(int(input()))
    if o:
        cnt+=1
print(cnt)