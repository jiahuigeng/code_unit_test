import math

cou = 0
n = int(input())
A = [int(input()) for i in range(n)]

for i in range(n):
    a_sq = int(math.sqrt(A[i]))
    for j in range(2,a_sq+2):
        if(A[i]%j==0 and not(A[i]==j)):
            break
        if(j==a_sq+1):
            cou += 1

print(cou)

