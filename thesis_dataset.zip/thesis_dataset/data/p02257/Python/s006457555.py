n=int(input())
A=[0]*n
cnt=0
for i in range(0,n):
    A[i]=int(input())
for i in range(0,n):
    if A[i]<2: pass
    elif A[i]==2 or A[i]==3:
        cnt+=1
    else:
        for j in range(2,A[i]):
            if A[i]%j==0: 
                break
            else: pass
            if j==i-1:
                cnt+=1
            else: pass
print(cnt)
