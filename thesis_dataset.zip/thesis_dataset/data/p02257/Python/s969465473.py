N = int(input())


def isPrime(n):
    if n == 2: return True
    elif n <= 1:return False
    i = 2
    while i ** 2 <= n:
        if n % i == 0:
            return False
        i += 1
    return True


cnt = 0
for i in range(N):
    a = int(input())
    if isPrime(a):
        cnt+= 1
print(cnt)


