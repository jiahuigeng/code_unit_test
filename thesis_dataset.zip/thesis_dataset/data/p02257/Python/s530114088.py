import math

def Eratos(n):
	primes = [2]
	num = [2*i+1 for i in range(1,n//2)]
	tmp = []

	top = 1
	while top < math.sqrt(n):
		top = num[0]
		for i in range(1,len(num)):
			if num[i] % top != 0:
				tmp.append(num[i])
		num = tmp
		tmp = []
		primes.append(top)
	for i in range(len(num)):
		primes.append(num[i])
	return primes

n = int(input())
cont = 0
primes = Eratos(15000)
for i in range(n):
	a = int(input())
	if a<10000:
		if primes.count(a)!=0:
			cont += 1
	else:
		for j in range(len(primes)):
			if a%primes[j]==0:
				break
			else:
				if math.sqrt(a)<primes[j]:
					cont += 1
					break
print(cont)
