import math

def Eratos(n):
	primes = [2]
	num = [2*i+1 for i in range(1,n//2)]
	tmp = []

	top = 1
	while top < math.sqrt(n):
		top = num[0]
		for i in range(1,len(num)):
			if num[i] % top != 0:
				tmp.append(num[i])
		num = tmp
		tmp = []
		primes.append(top)
	for i in range(len(num)):
		primes.append(num[i])
	return primes

n = int(input())
cont = 0
primes = Eratos(10000)
for i in range(n):
	a = int(input())
	if a==2 or a==5:
		cont += 1
	if a%10==1 or a%10==3 or a%10==7 or a%10==9:
		if a<10000:
			if primes.count(a)!=0:
				cont += 1
		else:
			for j in range(len(primes)):
				if math.sqrt(a)<primes[j]:
					cont += 1
					break
				elif a%primes[j]==0:
					break
print(cont)
