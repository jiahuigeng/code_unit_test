#include<bits/stdc++.h>
#define V vector
#define VI vector<int>
#define VVI vector<vector<int>>
#define rep(i,n) for(int i=0;i<(n);i++)
#define MOD 1000000007
using namespace std;
typedef long long ll;

int gcd(int a,int b){
    if(b==0)return a;
    else return gcd(b,a%b);
}

int main(void){
    int x,y;
    cin>>x>>y;
    int ans=1+x+y-gcd(x,y);
    cout<<ans<<endl;
}



