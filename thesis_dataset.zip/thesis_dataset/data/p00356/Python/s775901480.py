print((lambda x : int(x[0]) + int(x[1]) + 1 - (lambda *x, f=lambda f, x, y: f(f, y, x % y) if y else x: f(f, *x))(int(x[0]),int(x[1])))(input().split()))

