x, y = map(int, input().split())
if x == y:
    print(x+1)
else:
    print(min(x, y ) + 1 + abs(x - y) * 2)
