var n, d, x;
var p = [];
var dp = [];

function main(){
	n = scan();
	d = scan();
	x = scan();
	rep(d, function(i){
		p[i] = [];
		rep(n, function(j){
			p[i][j] = scan();
		});
	});

	dp[0] = x;
	rep(1, d, function(i){
		var dx = [];
		rep(n, function(j){
			dx[j] = [p[i][j] - p[i - 1][j], p[i - 1][j]];
		});
		dx.sort(function(a, b){
			if(a[0] != b[0]){
				return b[0] - a[0];
			}
			return a[1] - b[1];
		});

		var a = dp[i - 1];
		var b = dp[i - 1];
		rep(n, function(j){
			if(dx[j][0] <= 0){
				return false;
			}
			var k = Math.floor(a / dx[j][1]);
			a -= k * dx[j][1];
			b += k * dx[j][0];
		});
		dp[i] = b;
	});

	print(dp[d - 1]);
}

function rep(a, b, c){
	if(c === undefined){
		c = b;
		b = a;
		a = 0;
	}
	for(var i = a; i < b; ++i){
		if(c(i) === false){
			break;
		}
	}
}

var input = '';

function scan(){
	return +input.pop();
}
function scan_string(){
	return input.pop();
} 
function print(val){
	console.log(val);
}
 
process.stdin.resume();
process.stdin.setEncoding('utf8');
process.stdin.on('data', function(chunk){
	input += chunk;
});
process.stdin.on('end', function(){
	input = input.trim().split(/\s+/).reverse();
	main();
});