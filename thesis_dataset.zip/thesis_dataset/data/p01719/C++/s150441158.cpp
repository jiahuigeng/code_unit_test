// Template {{{
#include <bits/stdc++.h>
#define REP(i,n) for(int i=0; i<(int)(n); ++i)
using namespace std;
typedef long long LL;

#ifdef LOCAL
#include "contest.h"
#else
#define dump(x) 
#endif

class range {
    struct Iterator {
        int val, inc;
        int operator*() {return val;}
        bool operator!=(Iterator& rhs) {return val < rhs.val;}
        void operator++() {val += inc;}
    };
    Iterator i, n;
    public:
    range(int e) : i({0, 1}), n({e, 1}) {}
    range(int b, int e) : i({b, 1}), n({e, 1}) {}
    range(int b, int e, int inc) : i({b, inc}), n({e, inc}) {}
    Iterator& begin() {return i;}
    Iterator& end() {return n;}
};

const int dx[4] = {1, 0, -1, 0};
const int dy[4] = {0, 1, 0, -1};
inline bool valid(int x, int w) { return 0 <= x && x < w; }

void iostream_init() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.setf(ios::fixed);
    cout.precision(12);
}
//}}}

const int D = 100100;
vector<int> calc(vector<int> p, vector<int> q) {
    vector<int> res(D);
    for(int x = 0; x < D; x++) {
        res[x] = x;
        REP(i, p.size()) {
            if(x-p[i] >= 0) {
                res[x] = max(res[x], res[x-p[i]] + q[i]);
            }
        }
    }
    return res;
}
int main(){
    iostream_init();
    int n, d, x;
    while(cin >> n >> d >> x) {
        vector<vector<int>> ps(d, vector<int>(n));
        REP(i, d) REP(j, n) {
            cin >> ps[i][j];
        }
        REP(i, d-1) {
            auto next = calc(ps[i], ps[i+1]);
            x = next[x];
        }
        cout << x << endl;
    }
    return 0;
}

/* vim:set foldmethod=marker: */