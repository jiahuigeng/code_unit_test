#include <iostream>
#include <algorithm>
using namespace std;
int n, d, x, a[12][12], dp[100009];
int main() {
	cin >> n >> d >> x;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < n; j++) cin >> a[i][j];
	}
	for (int i = 1; i < d; i++) {
		for (int j = 1; j <= x; j++) {
			dp[j] = 0;
			for (int k = 0; k < n; k++) {
				if (j >= a[i - 1][k]) dp[j] = max(dp[j], dp[j - a[i - 1][k]] + a[i][k]);
			}
		}
		x = dp[x];
	}
	cout << x << endl;
	return 0;
}