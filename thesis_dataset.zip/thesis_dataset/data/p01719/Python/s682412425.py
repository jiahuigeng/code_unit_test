#!/usr/bin/env python
# -*- coding: utf-8 -*-

n,d,x = map(int,input().split())
weights = []
for i in range(d):
    weights.append(list(map(int,input().split())))

prices = []
for i in range(d-1):
    prices.append([weights[i+1][j] - weights[i][j] for j in range(n)])

dp = [False for i in range(10**5+1)]
dp[0] = 0
bag = x
for i in range(d-1):
    for j in range(n):
        for k in range(10**5):
            if weights[i][j] + k < 10**5+1 and dp[k] is not False:
                dp[k+weights[i][j]] = max(dp[k+weights[i][j]],dp[k] + prices[i][j])
    bag = max(dp[:bag]) + bag

print(bag)