#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int N,K;

    cin >> N >> K;

    int dp[3][3][N];
    int menu[N];

    for(int i=0; i<N; ++i) {
        menu[i]=-1;
    }

    for(int i=0; i<K; ++i) {
        int a,b;
        cin >> a >> b;
        menu[a-1]=b-1;
    }

    for(int i=0; i<3; ++i) {
        for(int j=0; j<3; ++j) {
            dp[i][j][1]=0;
        }
    }

    if(menu[0]!=-1 && menu[1]!=-1) {
        dp[menu[0]][menu[1]][1]=1;
    } else if(menu[0]!=-1) {
        dp[menu[0]][0][1]=1;
        dp[menu[0]][1][1]=1;
        dp[menu[0]][2][1]=1;
    } else if(menu[1]!=-1) {
        dp[0][menu[0]][1]=1;
        dp[1][menu[0]][1]=1;
        dp[2][menu[0]][1]=1;
    } else {
        for(int i=0; i<3; ++i) {
            for(int j=0; j<3; ++j) {
                dp[i][j][1]=1;
            }
        }
    }

    for(int d=2; d<N; ++d) {
        if(menu[d]!=-1) {
            for(int i=0; i<3; ++i) {
                for(int j=0; j<3; ++j) {
                    if(j!=menu[d]) {
                        dp[i][j][d]=0;
                    } else {
                        dp[i][j][d]=dp[0][i][d-1]+dp[1][i][d-1]+dp[2][i][d-1];
                        if(i==j) dp[i][j][d]-=dp[i][i][d-1];
                    }
                    dp[i][j][d]%=10000;
                }
            }
        } else {
            for(int i=0; i<3; ++i) {
                for(int j=0; j<3; ++j) {
                    dp[i][j][d]=dp[0][i][d-1]+dp[1][i][d-1]+dp[2][i][d-1];
                    if(i==j) dp[i][j][d]-=dp[i][i][d-1];
                    dp[i][j][d]%=10000;
                }
            }
        }
    }

    int ans=0;

    for(int i=0; i<3; ++i) {
        for(int j=0; j<3; ++j) {
            ans+=dp[i][j][N-1];
            ans%=10000;
        }
    }

    cout << ans << endl;


    return 0;
}