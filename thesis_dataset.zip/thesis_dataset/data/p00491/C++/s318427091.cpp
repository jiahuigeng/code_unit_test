#include<iostream>
#include<cstring>
#include<map>
using namespace std;
typedef long long int ll;
ll dfs(int day,int r1,int r2);
ll dp[101][4][4];
int n,k;
map<int,int> plan;
int main(){
	cin >> n >> k;
	for(int i=0;i<k;i++){
		int a,b; cin >> a >> b;
		a--; plan[a] = b;
	}
	memset(dp,-1,sizeof(dp));
	cout << dfs(0,0,0) << endl;
}

ll dfs(int day,int r1,int r2){
	if(day==n) return 1;
	if(dp[day][r1][r2] != -1) return dp[day][r1][r2];
	if(plan[day] != 0){
		if(r1 == r2 && r1 == plan[day]) return 0;
		else return dfs(day+1,plan[day],r1)%10000;
	}
	ll ret = 0;
	for(int i=1;i<=3;i++){
		if(r1 == r2 && r1 == i) continue;
		ret += dfs(day+1,i,r1)%10000;
	}
	return dp[day][r1][r2] = ret%10000;
}