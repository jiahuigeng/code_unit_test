a={'A':1,'B':0,'C':0}
while 1:
    try:
        b,c=input().split(',')
        a[b],a[c]=a[c],a[b]
    except:
        for i in a:
            if a[i]:print(i)
        break