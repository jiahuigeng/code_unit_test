import sys

def convert(s):
    x = 0
    if s == "A":
        x = 0
    elif s == "B":
        x = 1
    elif s == "C":
        x = 2
    return x

def main():
    A = [0 for i in range(3)]
    A[0] = 1

    for line in sys.stdin:
        B = line.split(",")
        B[0] = convert(B[0])
        B[1] = B[1].replace("\n", "")
        B[1] = convert(B[1])

        tmp = A[B[0]]
        A[B[0]] = A[B[1]]
        A[B[1]] = tmp
    
    S = ["A", "B", "C"]
    for i in range(3):
        if A[i] == 1:
            print(S[i])


if __name__ == "__main__":
    main()
