import sys
c='ABC'
for e in sys.stdin:c=c.replace(e[0],'D').replace(e[2],e[0]).replace('D',e[2])
print(c[0])
