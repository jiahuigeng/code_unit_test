def char_int(x):
	if x=='A':
		return 0
	elif x=='B':
		return 1
	else:
		return 2


cup=['A','B','C']
while True:
	try:
		a,b=map(str,input().split(','))
		x,y=char_int(a),char_int(b)
		cup[x],cup[y]=cup[y],cup[x]

	except EOFError:
		break

if cup[0]=='A':
	print('A')
elif cup[1]=='A':
	print('B')
else:
	print('C')