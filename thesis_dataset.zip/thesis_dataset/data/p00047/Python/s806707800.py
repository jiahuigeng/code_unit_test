import sys
arr = [1,0,0]
for line in sys.stdin:
    s = line.split(',')
    if s[0] == 'A':
        n = 0
    elif s[0] == 'B':
        n = 1
    else:
        n = 2
    if s[1] == 'A':
        m = 0
    elif s[1] == 'B':
        m = 1
    else:
        m = 2
    
    if arr[n] == 1 or arr[m] == 1:
        t = arr[n]
        arr[n] = arr[m]
        arr[m] = t

for i in range(len(arr)):
    if arr[i] == 1:
        if i == 0:
            print('A')
        elif i == 1:
            print('B')
        else:
            print('C')