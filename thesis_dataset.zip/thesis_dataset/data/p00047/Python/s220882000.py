import sys

d = {'A': 0, 'B': 1, 'C': 2}
cup = [1, 0, 0]

for line in sys.stdin:
  try:
    a, b = [i for i in line.split(',')]
    cup[d[a]], cup[d[b]] = cup[d[b]], cup[d[a]]
  except:
    break
if cup[0] == 1:
  print('A')
elif cup[1] == 1:
  print('B')
else:
  print('C')