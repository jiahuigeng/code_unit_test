#include<iostream>
#include<string>
#include<stdio.h>
using namespace std;

int function(char x) {
	if (x == 'A')return 0;
	else if (x == 'B')return 1;
	else if (x == 'C')return 2;
}
int main() {
	char letter1,letter2; bool cup[3] = { true,false,false };
	while(scanf("%c,%c", &letter1, &letter2)!=EOF){
		bool tmp = cup[function(letter1)];
		cup[function(letter1)] = cup[function(letter2)];
		cup[function(letter2)]=tmp;
	}
	for (int i = 0; i < 3; i++) {
		if (cup[i]) { if (i == 0) { cout << "A" << endl; break; } else if (i == 1) { cout << "B" << endl; break; } else if (i == 2) { cout << "C" << endl; } }
	}
}
