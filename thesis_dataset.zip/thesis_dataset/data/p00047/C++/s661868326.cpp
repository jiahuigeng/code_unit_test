#define _CRT_SECURE_NO_WARNINGS 
#include <stdio.h>
#include <string.h>

int main(void)
{
	int A=1, B=0, C=0,box;
	char a[1], b[1];

	while (scanf("%c,%c", a, b) != EOF){
		
		if (a[1] == 'A' && b[1] == 'B'){
			box = A;
			A = B;
			B = box;
		}
		else if (a[1] == 'A' && b[1] == 'C'){
			box = A;
			A = C;
			C = box;
		}
		else if (a[1] == 'B' && b[1] == 'C'){
			box = B;
			B = C;
			C = box;
		}
		else if (a[1] == 'B' && b[1] == 'A'){
			box = B;
			B = A;
			A = box;
		}
		else if (a[1] == 'C' && b[1] == 'B'){
			box = C;
			C = B;
			B = box;
		}
		else if (a[1] == 'C' && b[1] == 'A'){
			box = C;
			C = A;
			A = box;
		}
		
	}

	if (A == 1){
		putchar('A');
	}
	else if (B == 1){
		putchar('B');
	}
	else if (C == 1){
		putchar('C');
	}

	putchar('\n');

	return 0;
}