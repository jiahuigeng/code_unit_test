var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var Arr=(input.trim()).split("\n");
var abc={A:1,B:0,C:0};

Arr.forEach(function(v){
var arr=v.split(",");
var m=abc[arr[0]];
abc[arr[0]]=abc[arr[1]];
abc[arr[1]]=m;
});

for (var i in abc){
if(abc[i]==1)console.log(i);
}