#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define N 10
int main(int argc, const char * argv[])
{
    int x=0;
    int max1=-1;
    int max2=-2;
    int max3=-3;
    
    for(int j=0; j<N; j++){
        scanf("%d\n",&x);
        if(max1<=x){
            max3=max2;
            max2=max1;
            max1=x;
        }else if(max2<=x){
            max3=max2;
            max2=x;
        }else if(max3<=x){
            max3=x;
        }
    }
    printf("%d\n",max1);
    printf("%d\n",max2);
    printf("%d\n",max3);
}