#include<iostream>
#include<string>
#include<vector>
#include<cmath>
#include<queue>
using namespace std;

int main(){
	
	priority_queue<int>Q;

	for (int i = 0; i < 10; i++){
		int tmp; cin >> tmp;
		Q.push(tmp);
	}

	for (int i = 0; i < 3; i++){
		cout << Q.top() << endl;
		Q.pop();
	}

	return 0;
}

