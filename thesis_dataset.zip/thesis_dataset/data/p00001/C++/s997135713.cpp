#include <iostream>
using namespace std;
int main(void){
int i, j, n[10], max, temp;

for(i=0; i<10; i++){
cin>>n[i];
}

for(i=0; i<10; i++){
max = i;
for(j = i + 1; j < 10; j++){
if(n[max] < n[j]) max = j;
}
temp = n[max];
n[max] = n[i];
n[i] = temp;

while(i==0){
cout<<temp<<endl;
break;
}
while(i==1){
cout<<temp<<endl;
break;
}
while(i==2){
cout<<temp<<endl;
break;
}

}
}
