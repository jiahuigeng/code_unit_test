#include <iostream>
using namespace std;

int main()
{
	short int h[10] = {}, n[3] = {};
	for (int i = 0; i < 10; i++) {
		cin >> h[i];
		if (h[i] > h[n[0]]) {
			n[2] = n[1];
			n[1] = n[0];
			n[0] = i;
		}
		else if (h[i] > h[n[1]]) {
			n[2] = n[1];
			n[1] = i;
		}
		else if (h[i] > h[n[2]]) {
			n[2] = i;
		}
	}
	for (int i = 0; i < 3; i++) {
		cout << h[n[i]] << endl;
	}
	return 0;
}