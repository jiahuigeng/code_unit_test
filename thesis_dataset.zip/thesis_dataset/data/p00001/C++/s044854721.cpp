#include<iostream>
#include<utility>
using namespace std;

int main(){
	
	int height[10] = {};

	for(int i = 0; i < 10; i++){
		cin >> height[i];
	}

	int f = 0, s = 0, t = 0;

	for (int i = 0; i < 9; i++){
		if (height[i] >= t){
			t = height[i];
		}
		if (t >= s){
			swap(s, t);
		}
		if (s >= f){
		swap(f,s);
		}
	}
    
	cout << f << "\n" << s << "\n" << t << endl;

		return 0;
}