#include<stdio.h>
int main(void)
{
	int a, b, max, max2, max3;
	max = 0;
	max2 = 0;
	max3 = 0;
	for (a = 1; a <= 10; a++) {
		scanf("%d", &b);
		if (b <= 10000) {
			if (b > max) {
				max2 = max;
				max = b;
			}
			else if (b > max2) {
				max3 = max2;
				max2 = b;

			}
			else if (b > max3) {
				max3 = b;
			}
		}
	}
	printf("%d\n", max);
	printf("%d\n", max2);
	printf("%d\n", max3);
	return 0;
}