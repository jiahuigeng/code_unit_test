#include<iostream>
#include<vector>
int main() {
	std::vector<int> h(10);
	std::vector<int> mh(3);
	for (int i = 0; i < 10; ++i)std::cin >> h[i];
	for (int i = 0; i < 3; ++i) mh[i] = 0;
	for (int i = 1; i < 10; ++i) {
		if (mh[0] < h[i])mh[0] = h[i], h[i]=0;
	}
	for (int i = 1; i < 10; ++i) {
		if (mh[1] < h[i])mh[1] = h[i], h[i] = 0;
	}
	for (int i = 1; i < 10; ++i) {
		if (mh[2] < h[i])mh[2] = h[i], h[i] = 0;
	}
	for (int i = 0; i < 3; ++i)std::cout << mh[i] << std::endl;
	return 0;
}