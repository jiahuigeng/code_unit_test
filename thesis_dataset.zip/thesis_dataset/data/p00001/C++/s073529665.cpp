#include <iostream>
#include <algorithm>
#include <stdio.h>
#define pri(dt) printf("%d\n",dt)
#define RPE0(loopTotal)  for(int i=0;i<=(loopTotal);i++)
#define RPE(loopTotal)  for(int i=1;i<=(loopTotal);i++)

int data[9];

using namespace std;
int main(void){
    
    
    RPE0(9) scanf("%d",&data[i]);
    sort(data+0,data+9,greater<int>());
    RPE0(2) pri(data[i]);
    data[9] = {};
}