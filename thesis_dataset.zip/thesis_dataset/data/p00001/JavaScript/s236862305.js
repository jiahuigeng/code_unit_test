function Main(input){
    var h = input.split("\n").map(function(x){return parseInt(x,10)});
    h.sort(function(a,b){return b-a;});
    console.log(h.slice(0,3).join("\n"));
}
//input
Main(require("fs").readFileSync("/dev/stdin", "utf8"));