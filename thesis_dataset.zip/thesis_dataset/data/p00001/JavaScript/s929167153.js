process.stdin.resume();
process.stdin.setEncoding('utf8');

process.stdin.on('data', function (chunk) {
    var aaa = chunk.toString();
    var line = aaa.split("\n")
    for(var i in line){
        line[i] = new Number(line[i])
    }
    
    line.sort(function(a,b){
        if( a > b ) return -1;
        if( a < b ) return 1;
        return 0;
    });
    //line.sort();
    for(var i = 0;i<3;i++){
        console.log(line[i].toString());
    }
    //console.log(line)
});