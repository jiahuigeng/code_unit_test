function Main(input){
    var h = input.split("\n").map(function(x){return parseInt(x,10)});
    h.sort(
	function(a,b){
	    if(a>b)return -1;
	    if(a<b)return 1;
	    return 0;
	}
    );
    console.log(h.slice(0,3).join("\n"));
}
//input
Main(require("fs").readFileSync("/dev/stdin", "utf8"));