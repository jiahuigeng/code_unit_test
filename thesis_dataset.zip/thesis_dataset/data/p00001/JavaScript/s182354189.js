(function(){
	'use strict';
	(function() {
		this.output = function() {
			console.log.apply( console, arguments );
		};
		this.stdin = process.openStdin();
		stdin.setEncoding('utf8');
		stdin.on('end', function(){
			process.exit();
		});
		this.fs = require('fs');
	}).call( this );
	(function(){
		(function input(next_func) {
			var list = [];
			stdin.on('data', function(chunk){
				var input_data = (function(){
					chunk.replace(/\\r/, '');
					return chunk.trim().split('\n');
				})(chunk);
				input_data.forEach(function(line){		
					list.push( parseInt(line.trim()) );			
				});
				if ( list.length >= 10 )
					return next_func(list);
			});
		}).call(this, function solve(list) {
			list.sort(function(a,b){
				return a < b;
			});
			var result = list.slice( 0, 3 );
			result.forEach(function(height){
				output(height);
			});
			process.exit();
		});
	}).call( this );
}).call(global);