function main(input) {
  input.split("\n")
  .map(function(str){
    return parseInt(str);
  })
  .sort(function(a,b){
    return b - a;
  })
  .slice(0,3)
  .map(function(height){
    console.log(height);
  });
}
main(require('fs').readFileSync('/dev/stdin','utf8'));