process.stdin.on("data",function(c){
	(c+"").trim().split("\n").sort(function(a,b){return b-a}).slice(0,3).forEach(function(a){console.log(a)});
}).resume();