var input = '';
process.stdin.resume();
process.stdin.setEncoding('utf8');
process.stdin.on('data', function(chunk) {
    input += chunk;
});
process.stdin.on('end', function() {
    var lines = input.split('\n');
    lines.sort(function(a, b){return b - a})
    lines.slice(0, 3).forEach(function(x) {
        console.log(x);
    });
});