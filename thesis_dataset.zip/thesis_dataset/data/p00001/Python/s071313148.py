max = 0
middle = 0
small = 0
x = 0
for i in range(10):
	x = int(input())
	if max < x :
		middle = max
		max = x
		x = 0
	elif middle < x :
		small = middle
		middle = x
		x = 0
	elif small < x :
		small = x
		x = 0
print(max)
print(middle)
print(small)