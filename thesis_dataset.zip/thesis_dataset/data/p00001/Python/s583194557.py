top_three = [0, 0, 0]
for i in range(10):
    input_height = int(input())
    if top_three[0] < input_height:
        top_three[2] = top_three[1]
        top_three[1] = top_three[0]
        top_three[0] = input_height
    elif top_three[1] < input_height:
        top_three[2] = top_three[1]
        top_three[1] = input_height
    elif top_three[2] < input_height:
        top_three[2] = input_height

print(top_three[0])
print(top_three[1])
print(top_three[2])
