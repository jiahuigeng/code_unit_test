x=[]
for i in range(10):
    s=int(input())
    x.append(int(s))

y=sorted(x)
print(y[9])
print(y[8])
print(y[7])

