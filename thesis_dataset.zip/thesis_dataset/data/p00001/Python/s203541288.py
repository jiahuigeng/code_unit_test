y=[]
for i in range(1,11):
    x=int(input())
    y.append(x)

for i in range(1,4):
    ma=max(y)
    print(ma)
    y.remove(ma)
