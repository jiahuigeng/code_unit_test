max1 = 0
middle = 0
small = 0
x = 0
for i in range(10):
	x = int(input())
	if max1 < x :
		middle = max1
		max1 = x
		x = 0
	elif middle < x :
		small = middle
		middle = x
		x = 0
	elif small <= x :
		small = x
		x = 0
	x = 0
print(max1)
print(middle)
print(small)