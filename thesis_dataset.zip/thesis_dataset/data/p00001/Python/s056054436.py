data = []
for i in range(10):
    data.append(int(input()))
data.sort(reverse=True)
for i in range(3):
    print(data[i])