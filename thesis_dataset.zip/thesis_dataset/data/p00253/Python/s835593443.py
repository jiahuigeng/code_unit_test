while 1:
    n = int(input())
    if n == 0:break
    h = list(map(int,input().split()))
    for i,v in enumerate(h):
        if i == 0:
            r = (1,2,3)

        elif i == len(h) - 2:
            r = (i-2,i-1,i+1)

        elif i == len(h) -1:
            # iが答え
            print(v)
            break
        else:
            r = (i-1,i+1,i+2)
        if (h[r[2]] - h[r[1]] == h[r[1]] - h[r[0]]):
            if i != 0:
                print(v)
                break
            elif h[1] - h[0] != h[2] - h[1]:
                print(v)
                break