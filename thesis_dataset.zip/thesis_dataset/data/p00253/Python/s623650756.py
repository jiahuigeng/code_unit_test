while True:
  n = int(input())
  if n == 0:
    break
  lst = list(map(int, input().split()))
  for i in range(n + 1):
    sample = lst[:i] + lst[i + 1:]
    correct = [sample[0] + (sample[1] - sample[0]) * j for j in range(n)]
    if sample == correct:
      print(lst[i])
      break
