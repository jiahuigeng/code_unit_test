#include<iostream>
using namespace std;
int main(void){
  int zatu=0,n,a;
  int t[100];
  int d[100];
  while(1){
    cin>>n;
    if(n==0)break;
    for(int i=0;i<=n;i++){
      cin>>t[i];
    }
    for(int i=1;i<=n;i++)d[i]=t[i]-t[i-1];
    d[0]=0;
    zatu=-1;
    if(d[1]==d[2]&&d[2]==d[3]){
      a=d[1];
    }else if(d[2]==d[3]&&d[3]==d[4]){
      zatu=0;
    }else if(d[1]==d[2]&&d[3]==d[4]){
      if(d[1]>d[3])a=d[1];
      if(d[1]<d[3])a=d[3];
    }else if(d[1]==d[2]){
      a=d[1];
    }else{
      a=d[3];
    }
    if(zatu==-1){
      for(int i=1;i<=n;i++){
	if(a!=d[i]){
	  zatu=i;
	  break;
	}
      }
    }
    cout<<t[zatu]<<endl;
  }
  return 0;
}