import queue

INFTY = 1 << 21
WHITE = 0
GRAY = 1
BLACK = 2

def dijkstra(n, adj):
    pq = queue.PriorityQueue()
    d = [INFTY] * n
    color = [WHITE] * n

    d[0] = 0
    pq.put((0, 0))
    color[0] == GRAY

    while not pq.empty():
        f = pq.get()
        u = f[1]
        color[u] = BLACK

        if d[u] < f[0]:
            continue

        for j in range(len(adj[u])):
            v = adj[u][j][0]
            if color[v] == BLACK:
                continue
            if d[v] > d[u] + adj[u][j][1]:
                d[v] = d[u] + adj[u][j][1]
                pq.put((d[v], v))
                color[v] = GRAY

    for i in range(n):
        out = d[i]
        if out == INFTY:
            out = -1
        print('{0} {1}'.format(i, out))


n = int(input())
adj = [[] for i in range(n)]
for i in range(n):
    line = [int(v) for v in input().split()]
    u = line[0]
    k = line[1]
    for j in range(k):
        v = line[2*j + 2]
        c = line[2*j + 3]
        adj[u].append((v, c))

dijkstra(n, adj)
