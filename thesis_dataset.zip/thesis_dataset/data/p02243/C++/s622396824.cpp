#define _CRT_SECURE_NO_WARNINGS
#define _USE_MATH_DEFINES
#include <iostream>
#include <vector>
#include <queue>
#include <functional>
using namespace std;
const int INF = 2000000000;
const int num = 10000;
int n, k, u, v, w;
int c[num];
int d[num];
vector <pair<int, int> > ve[num];
int main() {
	priority_queue <pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
	fill(d, d + num, INF);
	d[0] = 0;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> u >> k;
		for (int j = 0; j < k; j++) {
			cin >> v >> w;
			ve[u].push_back(make_pair(v, w));
		}
	}
	fill(c, c + num, 0);
	q.push(make_pair(0, 0));
	while (!q.empty()) {
		int f = q.top().first;
		int s = q.top().second;
		q.pop();
		c[s] = 1;
		if (d[s] < f) continue;
		for (int i = 0; i < ve[s].size(); i++) {
			int fi = ve[s][i].first;
			int se = ve[s][i].second;
			if (c[fi]) continue;
			if (d[fi] > d[s] + se) {
				d[fi] = d[s] + se;
				q.push(make_pair(d[fi], fi));
			}
		}
	}
	for (int i = 0; i < n; i++) cout << i << " " << d[i] << endl;
	return 0;
}