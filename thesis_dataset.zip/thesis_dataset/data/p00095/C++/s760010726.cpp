#include <stdio.h>

int main(void)
{
	int i;
	int n;
	int a;
	int v;
	int ma;
	int mv;
	
	scanf("%d", &n);
	
	mv = 0;
	for (i = 0; i < n; i++){
		scanf("%d %d", &a, &v);
		
		if (v > mv){
			mv = v;
			ma = a;
		}
	}
	printf("%d %d\n", ma, mv);
	
	return (0);
}