#include<iostream>
#include<vector>
#include<algorithm>
#include<cstdio>
#include<map>
using namespace std;
struct data{
    int n,m;
    data(int a,int b){
        n=a;m=b;
    }
    data(){}
    bool operator<(const data &d)const{
        if(m!=d.m)return (m<d.m);
        else return (n>d.n);
    }

};
int main(){
    int n;
    cin>>n;
    data Max(100000,0);
    for(int i=0;i<n;i++){
        int p,q;
        cin>>p>>q;
        Max=max(Max,data(p,q));
    }
    cout<<Max.n<<" "<<Max.m<<endl;
}