num = int(input())

L = []
for i in range(num):
    p, v = [int(x) for x in input().split()]
    L.append([p, v])

L.sort(key=lambda x: (-x[1],x[0]))

print(L[0][0],L[0][1])

