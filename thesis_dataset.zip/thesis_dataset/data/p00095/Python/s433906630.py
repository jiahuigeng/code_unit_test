n = int(input())
a = [0 for i in range(n)]
v = [0 for i in range(n)]

for i in range(n):
    a[i], v[i] = [int(i) for i in input().split()]
v1 = sorted(v)
v2 = [v.index(i) for i in v1]
print(v2[-1]+1,v1[-1])
