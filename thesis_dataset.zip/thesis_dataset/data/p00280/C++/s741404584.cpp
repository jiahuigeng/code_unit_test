#include<bits/stdc++.h>
using namespace std;

set<string> se;
int j, y;

void dfs(int nj, int ny, string temp){
  if(j < nj || y < ny) return;
  if(j == nj && y == ny){
    se.insert(temp);
    return;
  }

  if(nj < 5 && ny <= 3 || ny < 5 && nj <= 3 || nj >= 4 && ny >= 4){
    dfs(nj + 1, ny, temp + 'A');
    dfs(nj, ny + 1, temp + 'B');
  }

  return;
}

int main(){
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);

  cin >> j >> y;

  dfs(0, 0, "");

  for(set<string>::iterator itr = se.begin();itr != se.end();itr++){
    cout << *itr << endl;
  }

  return 0;
}

