#include<iostream>
using namespace std;

int j,y;
void dfs(int a,int b,string game){
  if(a==j && b==y){
    cout<< game<< endl;
    return;
  }
  else if(a>j || b>y) return;
  else if((a<3 && b==5) || (a==5 && b<3) || (a==6 && b==6)) return;
  
  dfs(a+1,b,game+'A'); 
  dfs(a,b+1,game+'B');
}

main(){
  cin>> j>> y;
  dfs(0,0,"");
} 