# Aizu Problem 0285: Tennis

import sys, math, os, itertools

# read input:
PYDEV = os.environ.get('PYDEV')
if PYDEV=="True":
    sys.stdin = open("sample-input2.txt", "rt")


a, b = [int(_) for _ in input().split()]
L = ['A'] * a + ['B'] * b
perms = set()
for perm in itertools.permutations(L):
    perms.add(''.join(perm))

for perm in sorted(list(perms)):
    print(perm)