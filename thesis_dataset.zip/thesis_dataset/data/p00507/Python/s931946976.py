
n = int(input())
v=[]; ans=[]
for i in range(n):
    c=input()
    v.append(int(c))

v= sorted(v)[:min(len(v), 5)]
for i,d in enumerate(v):
    for i2,d2 in enumerate(v):
        if i==i2: continue;
        w=int(str(d) + str(d2))
        ans.append(w)
ans.sort()
print(ans[2])

