n = int(input())
a = [[] for i in range(5)]
for i in range(n):
    c = input()
    a[len(c) -1].append(c)
for i in range(5):
    a[i].sort()
b, c, d = 0, 0, 0
for i in range(5):
    if len(a[i]) != 0:
        if b == 0:
            b = len(a[i])
            if b >= 3:
                print(a[i][2] + a[i][0])
                break
            j = i
        elif c == 0:
            c = len(a[i])
            if b + c >= 3:
                if b == 1:
                    if c == 2:
                        e = [int(a[j][0] + a[i][0]), int(a[j][0] + a[i][1]), int(a[i][0] + a[j][0]), int(a[i][1] + a[j][0])]
                        e.sort()
                        print(e[2])
                    else:
                        e = [int(a[j][0] + a[i][0]), int(a[j][0] + a[i][1]), int(a[j][0] + a[i][2]), int(a[i][0] + a[j][0]), int(a[i][1] + a[j][0]), int(a[i][2] + a[j][0])]
                        e.sort()
                        print(e[2])
                else:
                    print(min(int(a[j][0] + a[i][0]), int(a[i][0] + a[j][0])))
                break
        else:
            print(min(int(a[j][0] + a[i][0]), int(a[i][0] + a[j][0])))
            break

