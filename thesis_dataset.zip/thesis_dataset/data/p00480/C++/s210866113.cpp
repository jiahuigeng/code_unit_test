#include<stdio.h>

int N=0,kazu[110]={};

long long int mena[25][110]={};

int main(){

	scanf("%d",&N);
	for (int i=1;i<=N;i++){
		scanf("%d",&kazu[N-i]);//??????????????\?????????
	}
	
	for (int i=1;i<21;i++){
		mena[i][N]=0;
	}
	for (int i=1;i<21;i++){
		mena[21][i]=0;
	}
	mena[0][N]=1;
//	printf("n???%d??§???\n",N);
	for (int j=N-1;j>=0;j--){
		for (int i=20;i>=0;i--){
			mena[i][j]=0;
	//	if (i==8&&j==3)printf("%I64d??§???",mena[i][j]);
			if (i+kazu[j]<=20)mena[i][j]=mena[i][j]+mena[i+kazu[j]][j+1];
	//	if (i==8&&j==3)printf("%I64d??§???",mena[i][j]);
			if (i-kazu[j]>=0)mena[i][j]=mena[i][j]+mena[i-kazu[j]][j+1];
	//	if (i==8&&j==3)printf("%I64d??????????????????\n",mena[i][j]);
		}
	}

//	for (int i=0;i<=N;i++){
//		for (int j=0;j<=21;j++){
//			if (mena[j][i]<0)printf("???????????????(%d,%d)?????£??£???",j,i);
//			printf("%I64d*",mena[j][i]);
//		}
//		printf("\n");
//	}
	
	printf("%lld\n",mena[kazu[0]][1]);
	
	return 0;
}