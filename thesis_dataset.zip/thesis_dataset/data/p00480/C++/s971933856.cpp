#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

int main(void) {
  int n;
  cin >> n;

  vector<int> a(n), b;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  for (int i = 0; i < n - 2; i++) {
    b.push_back(a[i + 1]);
  }

  ll dp[110][30] = {};
  dp[0][a[0]] = 1;
  for (int i = 0; i < b.size(); i++) {
    for (int j = 0; j <= 20; j++) {
      if (j - b[i] >= 0) {
        dp[i + 1][j] += dp[i][j - b[i]];
      }
      if (j + b[i] <= 20) {
        dp[i + 1][j] += dp[i][j + b[i]];
      }
    }
  }

  cout << dp[b.size()][a[n - 1]] << endl;

  return 0;
}
