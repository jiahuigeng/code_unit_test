var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var Arr=(input.trim()).split("\n");
var n=Arr.shift()-0;
var arr=(Arr.shift()).split(" ").map(Number);
var last=arr.pop();
n--;
var dp=[];
for(var i=0;i<n;i++){
   dp[i]=[];
   for(var j=0;j<=20;j++){
      dp[i][j]=0;
   }
}
dp[0][arr[0]]=1;
for(var i=1;i<n;i++){
   var v=arr[i];
   for(var j=0;j<=20;j++){
      if(dp[i-1][j]>=1){
         if(j+v<=20)dp[i][j+v]+=dp[i-1][j];
         if(j-v>=0)dp[i][j-v]+=dp[i-1][j];
      }
   }
}
console.log(dp[n-1][last]);