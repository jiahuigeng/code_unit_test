#include<bits/stdc++.h>
using namespace std;
int main(){
  int n,a,b,c,d;
  cin>>n>>a>>b>>c>>d;
  if(n%a==0) a=n/a;
  else a=n/a+1;
  if(n%c==0) c=n/c;
  else a=n/c+1;
  if(a*b>c*d) cout<<c*d<<endl;
  else cout<<a*b<<endl;
  return 0;
}

