#include<iostream>
#include<vector>
#include<algorithm>
#include<string>
using namespace std;
int cl(int a, int b) {
	return (a - (a%b)) / b;//b=0だと積む
}
int up(int a, int b) {
	return cl(a + b - 1, b);//b=0だと積む
}
int main() {
	int n, a, b, c, d, k, l;
	cin >> n >> a >> b >> c >> d;
	k = up(n,a);
	l = up(n,c);
	if (k*b >= l * d) {
		cout << l * d << endl;
	}
	else {
		cout << k * b<<endl;
	}
}
