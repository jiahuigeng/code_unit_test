#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<map>
#include<stack>
#include<cmath>
#include<iomanip>
#include<set>
#include<numeric>
#include<sstream>
#include<random>
#include<cassert>
using namespace std;
typedef long long ll;
#define rep(i, n) for (int i = 0; i < n; ++i)
#define rrep(i, st, n) for (int i = st; i < n; ++i)
using pii = pair<int, int>;
const int inf = 1e9 + 7;
int dy[] = {0, 0, -1, 1, -1, 1, -1, 1};
int dx[] = {1, -1, 0, 0, -1, 1, 1, -1};
#define ceil(a, b) a / b + !!(a % b)

int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);
    int n; cin >> n;
    int a[101][101] = {0};
    rrep(i, 1, n + 1) rrep(j, 1, n + 1) cin >> a[i][j];
    rrep(i, 1, n + 1) rep(j, n + 1) a[i][j] += a[i - 1][j];
    rep(i, n + 1) rrep(j, 1, n + 1) a[i][j] += a[i][j - 1];
    /*
    rep(i, n + 1) {
        rep(j, n + 1) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }
    */
    int ans = -inf;
    rep(i, n) rep(j, n) {
        rrep(k, i + 1, n + 1) rrep(l, j + 1, n + 1) {
            ans = max(ans, a[k][l] - a[k][j] - a[i][l] + a[i][j]);
        }
    }
    cout << ans << endl;
}


