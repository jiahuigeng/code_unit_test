#include <stdio.h>
#include <cctype>
#include <limits.h>
#include <math.h>
#include <complex>
#include <bitset>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <cstring>
#include <string>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <iostream>

#define VARIABLE(x) cerr << #x << "=" << x << endl
#define BINARY(x) static_cast<bitset<16> >(x);
#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define REP(i,m,n) for (int i=m;i<(int)(n);i++)
#define if_range(x, y, w, h) if (0<=(int)(x) && (int)(x)<(int)(w) && 0<=(int)(y) && (int)(y)<(int)(h))

const int INF = 1000000000;
const double EPS = 1e-8;
const double PI = 3.14159;
int dx[4]={0, 1, 0, -1}, dy[4]={-1, 0, 1, 0};
using namespace std;
typedef long long ll;
//typedef pair<int, int> P;
struct P {
	int x, y, n;
	P(int n, int x, int y):n(n), x(x), y(y){}
	P(){}
};

/** Problem0098 : Maximum Sum Sequence II **/
int main()
{
	int table[101][101]={0};
	int sum[101][101]={0};
	int N;
	int ans=0;

	cin>>N;
	REP(i, 1, N+1) {
		REP(j, 1, N+1) {
			cin>>table[i][j];
		}
	}
	
	sum[0][0] = table[0][0];
	REP(i, 1, N+1) {
		sum[i][0] = table[i][0]+sum[i-1][0];
		sum[0][i] = table[0][i]+sum[0][i-1];
		ans = max(ans, sum[i][0]);
		ans = max(ans, sum[0][i]);
	}
	
	REP(i, 1, N+1) {
		REP(j, 1, N+1) {
			sum[i][j] = sum[i-1][j] + sum[i][j-1] - sum[i-1][j-1] + table[i][j];
		}
	}
	
	REP(i, 1, N+1) {
		REP(j, 1, N+1) {
			REP(x, 1,i) {
				REP(y, 1, j) {
					ans = max(ans, sum[i][j]-sum[i][y-1]-sum[x-1][j]+sum[x-1][y-1]);
				}
			}
		}
	}
	
	cout << ans << endl;
}