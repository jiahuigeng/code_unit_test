# -*- coding: utf-8 -*-
"""
http://judge.u-aizu.ac.jp/onlinejudge/description.jsp?id=0098
TLE n=85だと通らない
"""
import sys
from sys import stdin
from functools import lru_cache
input = stdin.readline


def calc_points(n, array):
    # 右下から(x, y)までの長方形に含まれる値の和
    global dp
    for y in range(n - 1, -1, -1):
        for x in range(n - 1, -1, -1):
            dp[y][x] = dp[y+1][x] + dp[y][x+1] - dp[y+1][x+1] + array[y][x]


@lru_cache(maxsize=None)
def get_dp(y, x):
    return dp[y][x]


def solve(n, array):
    ans = 0
    calc_points(n, array)

    for sy in range(n + 1):
        for sx in range(n + 1):
            for ey in range(sy+1, n + 1):
                for ex in range(sx+1, n + 1):
                    s1 = get_dp(sy, sx)
                    s2 = get_dp(sy, ex)
                    s3 = get_dp(ey, sx)
                    s4 = get_dp(ey, ex)
                    s = s1 - s2 - s3 + s4
                    if s > ans:
                        ans = s
    return ans

dp = [[0] * (100 + 1) for _ in range(100 + 1)]
def main(args):
    array = []
    # n = 3
    # array.append([1, -2, 3])
    # array.append([-4, 5, 6])
    # array.append([7, 8, -9])

    n = int(input())
    for _ in range(n):
        array.append([int(x) for x in input().split()])
    ans = solve(n, array)
    print(ans)



if __name__ == '__main__':
    main(sys.argv[1:])

