n = int(input())

a = [list(map(int, input().split())) for i in range(n)]

# ?????????
sum_v = [[0 for i in range(n)] for i in range(n + 1)]
for i in range(n):
    c = 0
    for j in range(n):
        c += a[j][i]
        sum_v[j+1][i] = c

ans = -10**9


for sr in range(n):
    er = 0
    for er in range(sr, n):
        c = 0
        for col in range(n):
            c += sum_v[er+1][col] - sum_v[sr][col]
            ans = max(ans, c)
            if c < 0:
                c = 0  # c????????¢ (a(?????°) + b < b????????????

print(ans)