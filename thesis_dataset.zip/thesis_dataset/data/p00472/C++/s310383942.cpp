#include <iostream>
using namespace std;

int d[100005];
int p[100005];
int main(){
    int n,m;
    cin>>n>>m;
    for(int i=1; i<n; i++) cin>>d[i];
    for(int i=1; i<=m; i++) cin>>p[i];
    long long int ans=0;
    int w=1;
    for(int i=1; i<=m; i++){
        if(p[i]>=0) for(int j=w; j<w+p[i]; j++) ans+=d[j];
        else for(int j=w-1; j>=w+p[i]; j--) ans+=d[j];
        w+=p[i];
    }
    cout<<ans<<endl;
}