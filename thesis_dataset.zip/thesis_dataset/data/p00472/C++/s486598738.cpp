#include <bits/stdc++.h>

#define LL long long
#define VI vector<int>
#define VVI vector<vector<int>>
#define VVVI vector<vector<vector<int>>>
#define VVVVI vector<vector<vector<vector<int>>>>
#define VL vector<LL>
#define VVL vector<vector<LL>>
#define VVVL vector<vector<vector<LL>>>
#define VVVVL vector<vector<vector<vector<LL>>>>
#define VB vector<bool>
#define FOR(i,a,b) for(int i= (a); i<((int)b); ++i)
#define RFOR(i,a) for(int i=(a); i >= 0; --i)
#define FOE(i,a) for(auto i : a)
#define ALL(c) (c).begin(), (c).end()
#define RALL(c) (c).rbegin(), (c).rend()
#define DUMP(x)  cerr << #x << " = " << (x) << endl;
#define SUM(x) std::accumulate(ALL(x), 0LL)
#define MIN(v) *std::min_element(v.begin(), v.end())
#define MAX(v) *std::max_element(v.begin(), v.end())
#define EXIST(v,x) (std::find(v.begin(), v.end(), x) != v.end())
#define BIT(n) (1LL<<(n))
#define UNIQUE(v) v.erase(unique(v.begin(), v.end()), v.end());
#define EPS 1e-14

template<class T> T ceil(T a, T b) { return (a + b - 1) / b; }
template<class T> void print(T x) { std::cout << x << std::endl; }
inline bool inside(int y, int x, int H, int W) { return 0 <= y and y < H and 0 <= x and x < W; }

const std::string YES = "YES", Yes = "Yes", NO = "NO", No = "No";
const std::vector<int> dy = { 0, 1, 0, -1 }, dx = { 1, 0, -1, 0 };    // 4近傍（右, 下, 左, 上）

using namespace std;

class CumulativeSum {

public:
    vector<int> memo1;          // 1次元用の累積和表
    vector<vector<int>> memo2;  // 2次元用の累積和表

    CumulativeSum(const vector<int> &line) {
        this->memo1.resize(line.size() + 1, 0);

        for (int i = 0; i < line.size(); ++i) {
            this->memo1[i + 1] = this->memo1[i] + line[i];
        }
    }

    // 2次元の累積和表を作成
    CumulativeSum(const vector<vector<int>> &board) {
        int height = board.size();
        int width = board[0].size();
        this->memo2 = vector<vector<int>>(height + 1, vector<int>(width + 1, 0));

        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                memo2[y + 1][x + 1] = board[y][x] + memo2[y + 1][x];
            }
            for (int x = 0; x < width; ++x) {
                memo2[y + 1][x + 1] += memo2[y][x + 1];
            }
        }
    }

    int sum(int left, int right) {
        return this->memo1[right] - this->memo1[left];
    }

    /*
    (y1, x1)から(y2, x2)の合計を返す．(y2, x2)は含まない
    座標はmemoを作成したboard準拠
    (ex, sum(0, 0, 2, 2)なら(0, 0), (0, 1), (1, 0), (1, 1)の合計を返す)
    */
    int sum(int y1, int x1, int y2, int x2) {
        return this->memo2[y2][x2] - this->memo2[y2][x1] - this->memo2[y1][x2] + this->memo2[y1][x1];
    }

};

int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);

    int n, m;
    cin >> n >> m;
    VI A(n - 1), B(m);
    FOR(i, 0, n - 1) {
        cin >> A[i];
    }

    FOR(i, 0, m) {
        cin >> B[i];
    }

    CumulativeSum cs(A);
    LL ans = 0;
    int now = 0;
    FOR(i, 0, B.size()) {
        int next = now + B[i];
        next = min(max(0, next), n);
        (ans += cs.sum(min(now, next), max(now, next))) %= 100000;

        now = next;
    }

    print(ans);

    return 0;
}
