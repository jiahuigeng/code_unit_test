#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <map>
#include <queue>
#include <deque>
#include <complex>
#define FOR(i,a,b) for(int i=(a);i<(int)(b);i++)
#define REP(i,a) FOR(i,0,a)
#define real() X
#define imag() Y
#include <iostream>
using namespace std;
typedef long long ll;
ll sumsum[200002];
ll sums(int s,int e){
	if(s>e)
		return 0;
	return sumsum[e+1]-sumsum[s];
}
ll divide(int ss,int ee){
	int s=ss;
	int e=ee;
	ll maxim=0;
	while(s<=e){
		int f=(s+e)/2;
		maxim=max(maxim,min(sums(ss,f),sums(f+1,ee)));
		if(sums(ss,f)<=sums(f+1,ee))
			s=f+1;
		else
			e=f-1;
	}
	return maxim;
}
int main() {
	ll N,p,s,sum=0;
	vector<ll> baum;
	cin >> N;
	REP(i,N){
		cin >> p;
		baum.push_back(p);
		sum+=p;
		sumsum[i+1]=sumsum[i]+p;
	}
	REP(i,N){
		baum.push_back(baum[i]);
		sumsum[N+i+1]=sumsum[N+i]+baum[i];
	}
	REP(i,N){
		baum.push_back(baum[i]);
		sumsum[N*2+i+1]=sumsum[N*2+i]+baum[i];
	}
	int head=0;
	ll maxim=0;
	REP(snake,N){
		while(sums(snake,head)*3<sum) head++;
		if(sums(snake+1,head)*3<sum){
			maxim=max(maxim,divide((head+1)%N,(snake+N-1)%N+N*((head+1)%N>(snake-1))));
		}
	}
	cout << maxim << endl;
	// your code goes here
	return 0;
}