#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>

using namespace std;

#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define REP(i,n)  FOR(i,0,n)
#define INT(a) int((a)+1e-9)
#define SUPpl 100002

typedef long long ll;

int i,j,k,l;
int pl;
ll ps[SUPpl*2];
ll sps[SUPpl*2+1];
ll re;
int rei=0,rej=0,rek=0;

void decideK(){
	int ak=j;
	int bk=l;
	while(bk-ak>1){
		k = (ak+bk)/2;
		if( sps[k]-sps[j] ==sps[l]-sps[k] ) {ak=k;bk=k;break;}
		if( sps[k]-sps[j] < sps[l]-sps[k] ) ak=k;
		if( sps[k]-sps[j] > sps[l]-sps[k] ) bk=k;
	}
	if(min(sps[ak]-sps[j],sps[l]-sps[ak]) >= min(sps[bk]-sps[j],sps[l]-sps[bk])) k=ak;
	else k=bk;
}

void decideJK(){
	int aj=i;
	int bj=l;
	while(bj-aj>1){
		j = (aj+bj)/2;
		decideK();
		if( sps[j]-sps[i] ==min(sps[k]-sps[j],sps[l]-sps[k]) ) {aj=j;bj=j;break;}
		if( sps[j]-sps[i] < min(sps[k]-sps[j],sps[l]-sps[k]) ) aj=j;
		if( sps[j]-sps[i] > min(sps[k]-sps[j],sps[l]-sps[k]) ) bj=j;
	}
	j=aj;
}

void decideIJK(){
	re=0;
	for(i=0;i<pl;i++){
		l=i+pl;
		decideJK();
		if(re<sps[j]-sps[i]){
			re=sps[j]-sps[i];
			rei=i;rej=j;rek=k;
		}
	}
}

int main(){
	cin >> pl;
	REP(pi,pl) cin>>ps[pi];
	REP(pi,pl) ps[pi+pl]=ps[pi];
	REP(pi,pl*2) sps[pi+1]=sps[pi]+ps[pi];

	decideIJK();
	cout<<re<<endl;

	return 0;
}