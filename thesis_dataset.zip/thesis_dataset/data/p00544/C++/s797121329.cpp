#include <bits/stdc++.h>
using namespace std;

int main()
{
	int N, M;
	cin >> N >> M;
	vector<string> S(N);
	for (int i = 0; i < N; i++) {
		cin >> S[i];
	}
	int res = N * M;
	for (int i = 0; i < N; i++) {
		for (int j = i + 1; j < N; j++) {
			int cnt = 0;
			for (int x = 0; x < N; x++) {
				for (int y = 0; y < M; y++) {
					if (x < i) {
						cnt += S[x][y] != 'W';
					}
					else if (x < j) {
						cnt += S[x][y] != 'B';
					}
					else {
						cnt += S[x][y] != 'R';
					}
				}
			}
			res = min(res, cnt);
		}
	}
	cout << res << endl;
	return 0;
}

