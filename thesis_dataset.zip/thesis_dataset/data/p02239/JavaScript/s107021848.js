const input = require('fs').readFileSync('/dev/stdin', 'utf8');

const inputs = input.trim().split('\n');
const n = Number(inputs.shift());
const adj = inputs.map((s) => s.split(' ').map(Number));

class Node {
  constructor(id, list) {
    this.id = id;
    this.list = list || [];
  }
  toString() {
    return [this.id, this.depth !== undefined ? this.depth : -1].join(' ');
  }
}

class Graph {
  constructor() {
    this.queue = [];
    this.map = new Map();
  }
  get(id) {
    return this.map.get(id);
  }
  set(id, list) {
    this.map.set(id, new Node(id, list));
  }
  bfs() {
    const root = this.map.get(1);
    root.depth = 0;
    this.queue.push(root);
    while(this.queue.length) {
      const node = this.queue.shift();
      node.list.forEach(id => {
        const child = graph.map.get(id);
        if (child.depth !== undefined) {
          return;
        }
        child.depth = node.depth + 1;
        this.queue.push(child);
      })
    }
  }
  print() {
    for (let i = 1; i <= this.map.size; i++) {
      const node = this.map.get(i);
      console.log(node.toString());
    }
  }
}

const graph = new Graph();
adj.forEach(([id, k, ...ck]) => {
  graph.set(id, ck);
});
graph.bfs();
graph.print();

