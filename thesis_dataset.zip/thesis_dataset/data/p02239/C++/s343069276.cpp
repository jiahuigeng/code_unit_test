#include<bits/stdc++.h>
/*
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstring>
#include <complex>
#include <stack>
#include <queue>
#include <unordered_map>
#include <map>
*/
#define rep(i, a) for (int i = 0; i < (a); i++)
using namespace std;

int main(){
    int n;
    cin >> n;
    int g[110][110];
    int i, j;
    int u, k, v;
    pair<int, int> p;
    int dist[110];
    bool visited[110];
     
    for(i = 0; i < n; i++){
        for(j = 0; j < n; j++){
            g[i][j] = 0;
        }
    }
     
    for(i = 0; i < n; i++){
        dist[i] = -1;
        visited[i] = false;
    }
     
    for(i = 0; i < n; i++){
        cin >> u >> k;
        u--;
        for(j = 0; j < k; j++){
            cin >> v;
            v--;
            g[u][v] = 1;
        }
    }

	queue< pair<int, int> > q;
	for(i = 0; i < n; i++){
		if(g[0][i]) q.push(make_pair(0, i));
	}

	dist[0] = 0;
	visited[0] = true;
	while(!q.empty()){
		p = q.front();
		q.pop();

		if(visited[p.second]) continue;
		visited[p.second] = true;

		dist[p.second] = dist[p.first] + 1;

		for(j = 0; j < n; j++){
            if(g[p.second][j]){
                q.push(make_pair(p.second, j));
            }
        }
	}

	for(i = 0; i < n; i++){
        printf("%d %d\n", i+1, dist[i]);
    }
}

