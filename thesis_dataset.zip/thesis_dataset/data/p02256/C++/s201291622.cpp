#include<iostream>

int main(){

  int x,y,temp,r;

  std::cin>>x>>y;

  if(y>x){
    temp=x;
    y=x;
    x=temp;
  }

  r=x%y;
  while(r!=0){
    x=y;
    y=r;
    r=x%y;
}

  std::cout<<y<<"\n";
  return 0;
}

