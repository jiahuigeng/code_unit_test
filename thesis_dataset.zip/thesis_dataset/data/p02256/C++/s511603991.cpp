#include <iostream>
using namespace std;

int main() {
	int a,b, x;
	cin >> a >> b;
	if(a > b){
		for(int i=1; i<=a; i++){
			if(a%i==0 && b%i==0){
				x = i;
			}
		}
		cout << x << endl;
	}if(a==b){
		cout << a << endl;
	}
	return 0;
}