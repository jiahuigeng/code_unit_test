#include<stdio.h>

int main()
{
    int x,y;
    scanf("%d %d",&x,&y);
    if(x==y) printf("%d\n",x);
    else
    {
        int z,Z,n,k;
        if(x<y) z=x,Z=y;
        else z=y,Z=x;
        if(2*z<Z)
        {
            for(n=z;n>=1;n--)
            {
                if((z+Z)%n==0)
                {
                          k=n; 
                          break;
                }
             }
             printf("%d\n",k);
         }
         else
         {
              for(n=(Z/2)+1;n>=1;n--)
              {
                  if((z+Z)%n==0)
                  {
                          k=n;
                          break;
                  }
              }
              printf("%d\n",k);
          }
    }
}