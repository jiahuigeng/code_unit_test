process.stdin.resume();
process.stdin.setEncoding("utf8");

const reader = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout,
});

const lines = [];

reader.on("line", (line) => {
  lines.push(line);
});

reader.on("close", () => {
  let [m, n] = lines[0].split(" ").map(Number);
  if (m < n) {
    [m, n] = [n, m];
  }
  while (n != 0) {
    const t = n;
    n = m % n;
    m = t;
  }
  console.log(m);
});

