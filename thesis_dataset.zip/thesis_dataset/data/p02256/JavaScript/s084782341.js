const swap = (x, y) => {
  if (x < y) {
    tmp = x;
    x = y;
    y = tmp;
  }
  return [x, y];
};

const gcd = (x, y) => {
  [x, y] = swap(x, y);
  if (x % y === 0) {
    console.log(y);
    return y;
  } else {
    return gcd(y, x % y);
  }
};

process.stdin.resume();
process.stdin.setEncoding("utf8");
let input_string = "";

process.stdin.on("data", chunk => {
  input_string += chunk;
});

process.stdin.on("end", () => {
  const lines = input_string.split("\n");
  const input = lines[0].split(" ");
  gcd(input[0], input[1]);
});

