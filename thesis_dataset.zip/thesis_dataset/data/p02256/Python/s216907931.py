data = list(map(int,input().split()))
if(data[0] < data[1]): data[0],data[1] = data[1],data[0]
z = data[0] % data[1]
gcd = 0
for i in range(1,z):
    if(z%i == 0 and data[1]%i == 0 and gcd < i): gcd = i
print(gcd)
