def gcd( x, y):
  if x >= y and y != 0:
    gcd(y, x%y)
  else:
    print(x)

a,b = map(int, input().split())
gcd(a,b)

