import math
a,b=map(int,input().split())
print(math.gcd(a,b))

'''
# 00.02 sec    5588 KB    4 lines     55 bytes
a,b=map(int,input().split())
while b:a,b=b,a%b
print(a)
'''