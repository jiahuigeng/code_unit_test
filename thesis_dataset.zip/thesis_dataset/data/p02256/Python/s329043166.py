x,y=map(int,input().split())

def gg(a,b):
    for d in range(b,1,-1):
        #print(d)
        if a%d==0 and b%d==0:
            return d
if x>y:
    print(gg(x,y))
else:
    print(gg(y,x))

