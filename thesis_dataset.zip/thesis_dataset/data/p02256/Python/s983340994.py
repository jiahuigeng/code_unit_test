#ALDS1_1_B
import fractions
x , y = map(int,input().split())
print(fractions.gcd(x,y))
