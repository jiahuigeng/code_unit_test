#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <bitset>
  
#define rep(i, n) for(int i = 0; i < (n); i++)
#define FOR(i, a, b) for(int i = (a); i < (b); i++)
#define all(v) (v).begin(), (v).end()
#define rev(s) (s).rbegin(), (s).rend()
#define MP make_pair
#define X first
#define Y second
  
using namespace std;
  
typedef long long ll;
typedef pair<int, int> P;
typedef vector<int> vi;

int add(int &sum, int &n, int &cnt, int value){
    if(!n) return 0;
    n--;
    cnt++;
    sum+=value;
    return 1;
}

int main(){
    int a, b, c, d, e;
    while(cin >> a >> b >> c >> d >> e, a|b|c|d|e){
        int na, nb, nc;
        cin >> na >> nb >> nc;
        int sum = 0;
        if(nc >= d){
            sum += nc*e;
            nc = 0;
        }
        int cnt = nc, ssum = nc*c;
        while(na|nb){
           if(cnt == d){
               sum += min(ssum, d*e); 
               break;
           }
           if(add(ssum, nb, cnt, b)) continue;
           if(add(ssum, na, cnt, a)) continue;
        }
        sum += nb*b + na*a + min(ssum, d*e);
        cout << sum << endl;
    }
    return 0;
}