if __name__ == "__main__":
    while True:
        a, b, c, d, e = list(map(int, input().strip("\n").split(" ")))

        if a == 0 :
            exit()

        na, nb, nc = list(map(int, input().strip("\n").split(" ")))

        #print("--------------------")
        #print("abcde:", a, b, c, d, e)
        #print("na,nb,nc:", na, nb, nc, d)

        p0 = na * a + nb * b + nc * c  # wo set-wari

        if nc - d >= 0:
            # na1 = na
            # nb1 = nb
            p1 = na * a + nb * b + nc * e
        else:  # nc - d < 0
            d1 = d - nc  # d1 > 0
            if nb - d1 >= 0:
                p1 = na * a + (nb - d1) * b + d * e
            else:  # nb - d1 < 0
                d2 = d1 - nb  # > 0
                if na - d2 >= 0:
                    p1 = na * (na - d2) + d * e
                else:
                    p1 = p0

        #print("p0", p0)
        #print("p1", p1)
        print(min(p0,p1))