#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include <algorithm>
#include <set>
#include <iomanip>
#include <stdio.h>
#include <sstream>
#include <string>
using namespace std;
int main(void){
  long long int n;
  cin>>n;
  vector<long long int> r(n);
  for(long long int i=0; i<n; i++){
    cin>>r.at(i);
  }
  long long int maxv=-9999999999;
  long long int minv=r.at(0);
  for(long long int i=1; i<n; i++){
    minv=min(minv,r.at(i-1));
    maxv=max(maxv,r.at(i)-minv);
  }
  cout<<maxv<<endl;
  return 0;
}
