#include<iostream>
using namespace std;

int main(){
	int R[200000], max_gain, n, i,j;
	cin >> n;
	for(i=0;i<n;i++){
		cin >> R[i];
	}
	max_gain = R[0] - R[1];
	for(i=0;i<n-1;i++){
		for(j=i+1;j<n;j++){
			if(max_gain < R[j] - R[i])
				max_gain = R[j] -R[i];
		}
	}
	cout << max_gain << endl;
	return 0;
}