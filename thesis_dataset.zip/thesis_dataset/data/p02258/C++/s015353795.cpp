#include<bits/stdc++.h>
using namespace std;

long long int  profit[200050]={0};
int main()
{
		int n,sign=0;
		long long int min,max;
		scanf("%d",&n);
		for(int i  = 1 ; i <= n ; i++)
				scanf("%lld",&profit[i]);
		min=profit[1];
		for(int i  = 2 ; i <= n ; i++)
		{
				if(profit[i]<min)
				{
						min=profit[i];
						sign=i;
				}
		}
		max=profit[sign];
		for(int i = sign ; i <= n ; i++)
		{
				if(profit[i]>max)
				{
						max=profit[i];
				}
		}
		if((max-min)>0)
				printf("%lld\n",max-min);
		else
				printf("%lld\n",profit[2]-profit[1]);
		return 0;
}

