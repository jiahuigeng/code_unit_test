#include <cstdio>
#include <iostream>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <iomanip>
#include <cassert>
#include <bitset>
using namespace std;

typedef pair<int, int> P;
#define rep(i, n) for (int i=0; i<(n); i++)
#define all(c) (c).begin(), (c).end()
#define uniq(c) c.erase(unique(all(c)), (c).end())
#define _1 first
#define _2 second
#define pb push_back
#define INF 1145141919
#define MOD 1000000007

int N, M;
int D[300];
int dist[300];
vector<int> G[300], R[300];
vector<int> G2[300];
bool used[300];
int ord[300];

vector<int> vs;
void dfs(int x) {
  if (used[x]) return;
  used[x] = true;
  for (int t : G[x]) dfs(t);
  vs.pb(x);
}
void rdfs(int x, int k) {
  if (used[x]) return;
  used[x] = true;
  ord[x] = k;
  for (int t : R[x]) rdfs(t, k);
}

int scc() {
  vs.clear();
  rep(i, N) used[i] = false;
  rep(i, N) dfs(i);
  rep(i, N) used[i] = false;
  int k = 0;
  for (int i=vs.size()-1; i>=0; i--) {
    if (!used[vs[i]]) rdfs(vs[i], k++);
  }
  return k;
}
void dfs2(int x) {
  if (used[x]) return;
  used[x] = true;
  for (int t : G2[x]) dfs2(t);
}

signed main() {
  ios::sync_with_stdio(false); cin.tie(0);
  while (cin >> M) {
    if (M == 0) break;
    cin >> N;
    N+=2;
    D[0] = 0;
    rep(i, N-2) cin >> D[i+1];
    D[N-1] = 0;
    bool ng = false;
    rep(i, N) G[i].clear(), R[i].clear();
    rep(i, N-1) {
      for (int k=1; k<=M; k++) {
        int t = i+k;
        if (t > N) t = N;
        if (t < 0) t = 0;
        t += D[t];
        if (t > N) t = N;
        if (t < 0) t = 0;
        if (i == t) continue;
        G[i].pb(t);
        R[t].pb(i);
      }
    }
    int K = scc();
    rep(i, K) G2[i].clear();
    rep(i, N) {
      for (int t : G[i]) {
        if (ord[i] == ord[t]) continue;
        G2[ord[i]].pb(ord[t]);
      }
    }
    rep(i, K) {
      sort(all(G2[i])); uniq(G2[i]);
    }
    rep(i, N) used[i] = false;
    dfs2(ord[0]);
    rep(i, K) {
      if (i == ord[N-1]) continue;
      if (used[i] && G2[i].empty()) ng = true;
    }
    if (!ng) cout << "OK\n";
    else cout << "NG\n";
  }
  return 0;
}