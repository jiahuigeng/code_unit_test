while 1:
    m = int(input())
    if m == 0:break
    n = int(input())
    d = [int(input()) for _ in range(n)]
    if n < m:print("OK")
    for i in range(m):
        if d[- i - 1] > - m + i:break
    else:
        print("NG")
        continue
    print("OK")
