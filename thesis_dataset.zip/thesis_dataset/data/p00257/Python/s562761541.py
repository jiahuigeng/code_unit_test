def reachable(graph, init):
    if init not in graph or graph[init] is None:
        return set()
    
    tmp,  graph[init] = graph[init], None

    return tmp.union(* [reachable(graph, i) for i in tmp])

def sugoroku(m, d):
    d = [0] + d + [0]
    start, goal = 0, len(d) - 1

    graph_to = {goal:{goal}}
    graph_from = {start:{start}}
    
    for init in range(len(d) - 1):
        for xi in range(1, 1 + m):
            pos = min(init + xi, goal)
            to = max(start, min(pos + d[pos],goal))
            try:
                graph_to[to].add(init)
            except KeyError:
                graph_to[to] = {init}
            try:
                graph_from[init].add(to)
            except KeyError:
                graph_from[init] = {to}
    
    unreachable_node = reachable(graph_from, start).difference(reachable(graph_to, goal))
    
    return 0 == len(unreachable_node)

import sys
f = sys.stdin

while True:
    m = int(f.readline())
    if m == 0:
        break
    d = [int(f.readline()) for _ in range(int(f.readline()))]
    print('OK' if sugoroku(m, d) else 'NG')