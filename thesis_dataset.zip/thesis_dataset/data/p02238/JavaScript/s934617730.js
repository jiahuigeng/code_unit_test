//config = { input: 'tmp', newline: '\r\n' }; // win
config = { input: '/dev/stdin', newline: '\n' }; // linux

line = require('fs').readFileSync(config.input, 'ascii')
  .trim()
  .split(config.newline);
n = Number(line.shift());
adj = {};
for (i in line) {
  ary = line[i].split(' ');
  j = ary.shift();
  ary.shift();
  adj[j] = ary;
}

for (i in adj)
  adj[i].sort(function (a, b) { return Number(a) - Number(b); });

d = {};
f = {};
t = 0;
token = null;

function find(ary, callback) {
  var filtered;
  filtered = ary.filter(callback);
  if (filtered.length === 0) return undefined;
  return filtered[0];
}

function move(to) {
  if (d.hasOwnProperty(token)) f[token] = t;
  token = to;
  t++;
  if (!d.hasOwnProperty(to)) d[to] = t;
}

function round(from) {
  var next, stack = [null];
  move(from);
  do {
    next = find(adj[token], function (node) {
      return !d.hasOwnProperty(node); });
    if (next) {
      stack.push(token);
      move(next);
    } else {
      if (!f.hasOwnProperty(token))
        move(token);
      move(stack.pop());
    }
  } while (token);
  t--;
}

for (i = 1; i <= n; i++) {
  if (!d.hasOwnProperty(String(i))) round(String(i));
}

for (i = 1; i <= n; i++)
  console.log("%d %s %s", i, d[i], f[i]);