#include <iostream>
#include "memory.h"
#include <stack>

using namespace std;

bool matrix[100][100];
int n;

int next(int k){
	for(int i = 0; i < n; i++){
		if(matrix[k][i] == true)
			return i + 1;
	}
	return false;
}

int main(){
	int index, temp, num, current, count = 1;
	int start_end[100][2];
	stack<int> back;

	memset(matrix, 0, sizeof(matrix));
	memset(start_end, 0, sizeof(start_end));

	cin >> n;

	for(int i = 0; i < n; i++){
		cin >> index >> num;
		while(num--){
			cin >> temp;
			matrix[index-1][temp-1] = true;
		}
	}
	back.push(0);
	current = 0;
	while(true){
		while(!back.empty()){
			int r;
			r = next(current);
			if(start_end[current][0] == 0){
				start_end[current][0] = count;
				count++;
			}
			if(r){
				matrix[current][r-1] = false;
				back.push(current);
				current = r - 1;
			}
			else{
				if(start_end[current][1] == 0){
					start_end[current][1] = count;
					count++;
				}
				current = back.top();
				back.pop();
			}
		
		}
		for(int i = 0; i < n; i++){
			if(start_end[i][0] == 0 || start_end[i][1] == 0){
				back.push(i);
				break;
			}
		}
		if(back.empty())
			break;
	}
	for(int i = 0; i < n; i++){
		cout << i + 1 << " " << start_end[i][0] << " " << start_end[i][1] << endl;
	}

}
