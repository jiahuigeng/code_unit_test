#include <iostream>
#include <stack>
using namespace std;
static const int N = 100;
static const int WHITE= 0;
static const int GRAY = 1;
static const int BLACK = 2;

int n, M[N][N];
int color[N], D[N], F[N], TT;
int NT[N];

int next(int U) {
	for (int v = NT[U]; v < N; v++) {
		NT[U] = v + 1;
		if (M[U][v]) return v;
	}
	return -1;
}

void dfs_visit(int R) {
	for (int i = 0; i < n; i++) NT[i] = 0;

	stack<int>S;
	S.push(R);
	color[R] = GRAY;
	D[R] = ++TT;

	while (!S.empty()) {
		int U = S.top();
		int V = next(U);
		if (V != -1) {
			if (color[V] == WHITE) {
				color[V] = GRAY;
				D[V] = ++TT;
				S.push(V);
			}
		}
		else {
			S.pop();
			color[U] = BLACK;
			F[U] = ++TT;
		}
	}
}

void dfs() {
	for (int i = 0; i < n; i++) {
		color[i] = WHITE;
		NT[i] = 0;
	}
	TT = 0;
	for (int u = 0; u < n; u++) {
		if (color[u] == WHITE) dfs_visit(u);
	}
	for (int i = 0; i < n; i++) {
		cout << i + 1 << " " << D[i] << " " << F[i] << endl;
	}
}

int main() {
	int U, K, V;
	cin >> n;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) M[i][j] = 0;
	}
	for (int i = 0; i < n; i++) {
		cin >> U >> K;
		U--;
		for (int j = 0; j < K; j++) {
			cin >> V;
			V--;
			M[U][V] = 1;
		}
	}

	dfs();
	return 0;
}
