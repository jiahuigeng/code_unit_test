#include<iostream>
using namespace std;

int main()
{
  int n, m = 0;
  cin >> n;
  while(n > 1)
  {
    n /= 3;
    if(m % 3 != 0)
      n++;
    m++;
  }
  cout << m << endl;
}