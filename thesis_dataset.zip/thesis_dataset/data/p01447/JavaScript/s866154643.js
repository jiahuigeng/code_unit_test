var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var n=input.trim()-0;
var cnt=0;
while(true){
   if(n<1)break;
   n/=3;
   cnt++;
}
console.log(cnt);