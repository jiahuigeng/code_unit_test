n = int(input())
ans = 0
while n > 1:
  ans += 1
  n = n // 3 + int(bool(n % 3))
print(ans)
