N = int(input())
i = 0
while True:
    N //= 3
    i += 1
    if N <= 1:
        print(i)
        break

